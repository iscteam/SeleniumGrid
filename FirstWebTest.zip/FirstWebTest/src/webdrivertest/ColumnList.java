package webdrivertest;

import java.util.ArrayList;

public class ColumnList extends ArrayList<String> {

	 /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public boolean addValue(String field) {
	  String value;
	  if (field.equals("null") || field.trim().isEmpty())
	   value = "";
	  // else if (field.equals("<SKIP>"))
	  // value = "SKIP";
	  else
	   value = field;
	  return this.add(value);
	 }
	}
