package webdrivertest;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Properties;
import java.util.regex.Pattern;

import javax.imageio.ImageIO;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.apache.commons.io.FileUtils;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.format.CellFormat;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Wait;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import org.w3c.dom.Document;
import org.xml.sax.SAXException;

import com.codoid.products.exception.FilloException;
import com.codoid.products.fillo.Connection;
import com.codoid.products.fillo.Recordset;

import jxl.Range;
import jxl.format.Alignment;
import jxl.format.Colour;
import jxl.format.VerticalAlignment;
import jxl.write.Label;
import jxl.write.WritableCell;
import jxl.write.WritableCellFormat;
import jxl.write.WritableFont;
import jxl.write.WritableHyperlink;
import jxl.write.WritableSheet;
import jxl.write.WritableFont.FontName;

public class MainTest {
	public static String TestCaseFile = "D:\\Selenium\\Datasheet-iNet.xlsx";
	public static String TestCaseSheet = "TestCases";
	public static String TestCaseColumnName = "Test Case Name";
	public static String TestCaseName = "LOGIN_ADMIN";
	public static String TestFlowFile = "D:\\Selenium\\Datasheet-iNet.xlsx";
	public static String TestFlowSheet = "TestFlow";
	public static String TestFlowColumnName = "Scenario Name";
	public static String TestFlowName = "LOGIN";
	public static String ObjectRepoFile = "D:\\Selenium\\Datasheet-iNet.xlsx";
	public static String ObjectRepoSheet = "ObjectRepository";
	public static String GlobalDataFile = "D:\\Selenium\\Datasheet-iNet.xlsx";
	public static String GlobalDataSheet = "GlobalTestData";
	public static String ScreenShotsSaveLocation = "D:\\TestRun_1\\Screenshots";
	public static String TestCycleName = "";
	public static String ResultsFolder = "";
	public static String SummaryReportFile = "";
	public static String DetailedReportFile = "";
	public static String SummaryReportHandle = "SummaryReport";
	public static String DetailedReportHandle = "DetailedReport";
	public static String TestRunName = "";
	public static String ExecutedBy = "";
	public static int detailedCount = 0;
	public static ArrayList<ColumnList> arrList=null;

	//Variable declarations required for executeTestStep.
	static Calendar cal;
	static String testFlow = "";
	static String currentStep = "";
	static String previousStep = "";
	static String scenario = "";
	static int stepNum = 0;
	static String action = "";
	static String object = "";
	static String condition = "";
	static String screenshot = "";
	static String objectCol[];
	static String[] val = new String[5];
	static String a[];
	static int i = 0;
	static boolean previous = false;
	static int j = 0;
	static boolean current = false;
	static boolean state = true;
	static ArrayList<ColumnList> objectRep = new ArrayList<ColumnList>();
	static ArrayList<ColumnList> testData = new ArrayList<ColumnList>();
	static ExcelHelper h = new ExcelHelper();
	static Automation aut = new Automation();
	static boolean retryFind = true;
	//Variable declarations required for ReportGeneration.
	static String [] summaryHeaders = {"Test Case Name","Status","Screenshot","Execution Date","Start Time","End Time","Duration (in secs)","Comments"};
	static String [] detailedHeaders = {"Test Case Name","Test Flow Name","Steps","Action","Expected Result","Actual Result", "Screenshot","Status","Execution Date","Start Time","End Time","Duration (in secs)"};
	//static int summaryTestStepIndex = 6;
	//static int detailedTestStepIndex = 6;
	//static Date date = new Date();
	//static SimpleDateFormat dateFormat = new SimpleDateFormat("dd_MM_yyyy_HH_mm_ss");
	public static WritableCellFormat wm;
	public static final FontName font = WritableFont.createFont("Calibri");
	public static WritableFont wFont;
	public String nodeURL;
	@Parameters({"NodeURL"})
	@Test
	public void ExecuteMain(String NodeURL) throws Exception, FilloException
	{
		nodeURL = NodeURL;
		System.out.println("Inside execute main: "+ nodeURL);
		/*String path = TestNGMain.class.getProtectionDomain().getCodeSource().getLocation().getPath();
		path = new File(path).getParent();
		try {
			path = URLDecoder.decode(path, "UTF-8");
		} catch (UnsupportedEncodingException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		path = path + "\\Config.xml"; //"C:\\SeleniumFramework\\Config.xml"*/
		File fXmlFile = new File("E:\\Automation\\New folder\\Selenium\\SeleniumFramework\\Config.xml");
		DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
		DocumentBuilder dBuilder;
		Document doc;
		dBuilder = dbFactory.newDocumentBuilder();
		doc = dBuilder.parse(fXmlFile);
		
		TestCaseFile = doc.getDocumentElement().getElementsByTagName("TestCaseFile").item(0).getTextContent();
		TestCaseSheet = doc.getDocumentElement().getElementsByTagName("TestCaseSheet").item(0).getTextContent();
		TestFlowFile = doc.getDocumentElement().getElementsByTagName("TestFlowFile").item(0).getTextContent();
		TestFlowSheet = doc.getDocumentElement().getElementsByTagName("TestFlowSheet").item(0).getTextContent();
		ObjectRepoFile = doc.getDocumentElement().getElementsByTagName("ObjeRepoFile").item(0).getTextContent();
		ObjectRepoSheet = doc.getDocumentElement().getElementsByTagName("ObjeRepoSheet").item(0).getTextContent();
		GlobalDataFile = doc.getDocumentElement().getElementsByTagName("GlobDataFile").item(0).getTextContent();
		GlobalDataSheet = doc.getDocumentElement().getElementsByTagName("GlobDataSheet").item(0).getTextContent();
		ResultsFolder = doc.getDocumentElement().getElementsByTagName("ResultsFolder").item(0).getTextContent();
		SummaryReportFile = ResultsFolder + "\\" + doc.getDocumentElement().getElementsByTagName("SummaryReportFile").item(0).getTextContent() + ".xls";
		DetailedReportFile = ResultsFolder + "\\" + doc.getDocumentElement().getElementsByTagName("DetailedReportFile").item(0).getTextContent() + ".xls";
		TestCaseName = doc.getDocumentElement().getElementsByTagName("TestCaseName").item(0).getTextContent();
		TestCycleName = doc.getDocumentElement().getElementsByTagName("TestCycleName").item(0).getTextContent();
		TestRunName = doc.getDocumentElement().getElementsByTagName("TestRunName").item(0).getTextContent();
		ExecutedBy = doc.getDocumentElement().getElementsByTagName("ExecutedBy").item(0).getTextContent();
		//TestCaseName = args[0];

		System.out.println(TestCaseFile);
		System.out.println(TestCaseSheet);
		MainTest.processReportFiles();
		try
		{
			System.out.println("ExecuteMain try: " + NodeURL);
			MainTest.processTestCases(readTestCase(), NodeURL);
		}
		catch(Exception e){
			e.printStackTrace();
		}
		if(aut.browser != null)
			aut.Close();
		ExcelHelper.OpenWorkbook(new File(SummaryReportFile), SummaryReportHandle);
		ExcelHelper.OpenWorkbook(new File(DetailedReportFile), DetailedReportHandle);
		String ssh = ExcelHelper.openSheet(SummaryReportHandle, "Sheet1");
		String dsh = ExcelHelper.openSheet(DetailedReportHandle, "Sheet1");
		ExcelHelper.autoFit(ssh);
		ExcelHelper.autoFit(dsh);
		ExcelHelper.closeSheet("", ssh);
		ExcelHelper.closeSheet("", dsh);
		ExcelHelper.CloseWorkbook(DetailedReportHandle);
		ExcelHelper.CloseWorkbook(SummaryReportHandle);
		fillRow(Colour.GREY_40_PERCENT, DetailedReportFile);
	}
	public static void processReportFiles() throws Exception
	{
		File report = new File(SummaryReportFile);
		if(!report.exists())
		{
			System.out.println("No report files exist. Creating new ones");
			CreateDetailedReport(DetailedReportFile);
			CreateSummaryReport(SummaryReportFile);
			String sshandle = ExcelHelper.openSheet(SummaryReportHandle, "Sheet1");
			String sdhandle = ExcelHelper.openSheet(DetailedReportHandle, "Sheet1");
			logDetailedReportTitle(sdhandle);
			logSummaryReportTitle(sshandle);
			writeDetailedColumnHeaders(sdhandle);
			writeSummaryColumnHeaders(sshandle);
			ExcelHelper.closeSheet("", sdhandle);
			ExcelHelper.closeSheet("", sshandle);
			ExcelHelper.CloseWorkbook(DetailedReportHandle);
			ExcelHelper.CloseWorkbook(SummaryReportHandle);
			return;
		}
		return;
	}
	/*Methods required for TestCase execution starts here*/
	//Obtains TestCase and TestFlow required for executeTestStep().
	public static void processTestCases(ArrayList<ColumnList> testCaseList, String nodeURL) throws Exception
	{
		System.out.println("processTestCases: " + nodeURL);
		String testFlow = "";
		Teststep sumstep = new Teststep();
		cal = Calendar.getInstance();
		SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss");
		DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy HH:mm");
		Date date = new Date();
		sumstep.ExecutionDate = dateFormat.format(date);
		sumstep.TestCaseName = TestCaseName;
		long testStartTime = System.nanoTime();
		sumstep.StartTime = String.valueOf(sdf.format(Calendar.getInstance().getTime()));
		sumstep.Status = "Passed";
		Teststep state;
		ArrayList<ColumnList> testFlowList = null;
		HashMap<String, String> testCaseData = new HashMap<String, String>();
		for(int tcrow = 0;tcrow < testCaseList.size();tcrow++)
		{
			if(!testCaseList.get(tcrow).get(1).trim().isEmpty())
			{
				if(testFlowList != null)
				{
					if(testFlow.equalsIgnoreCase("CALIBRATION_HISTORY"))
						testFlow = "";
					state = executeTestStep(testFlowList, testCaseData, nodeURL);
					//if ((!state.Screenshot.isEmpty()) && state.Status.equalsIgnoreCase("failed"))
					if (state.Status.equalsIgnoreCase("failed"))
					{
						sumstep.Status = "Failed";
						sumstep.Duration = String.valueOf(Math.round((System.nanoTime() - testStartTime)/1000000000.0));
						sumstep.EndTime = String.valueOf(sdf.format(Calendar.getInstance().getTime()));
						sumstep.Screenshot = captureScreenshot(String.valueOf(stepNum));
						//sumstep.Screenshot = state.Screenshot;
						logProcessStepsSum(sumstep, SummaryReportFile);
						//logProcessStepsDet(sumstep, DetailedReportHandle);
						return;
					}
					testCaseData.clear();
					testFlowList = null;
					//fillRow(Colour.GREY_40_PERCENT, DetailedReportFile);
				}
				testFlow = testCaseList.get(tcrow).get(1);
				System.out.println(testFlow);
				testFlowList = readTestFlow(testCaseList.get(tcrow).get(1));
			}
			String testData = testCaseList.get(tcrow).get(3).trim();
			while(Pattern.matches("\\{(.*?)\\}*", testData))
			{
				String globaldata = testData.substring(testData.indexOf('{')+1, testData.indexOf('}'));
				testData = testData.replace("{" + globaldata + "}", readGlobalTestData(globaldata));
			}
			testCaseData.put(testCaseList.get(tcrow).get(2).trim(), testData);
		}
		if(testFlowList != null && testFlowList.size()>0)
		{
			state = executeTestStep(testFlowList, testCaseData, nodeURL);
			if(state.Status.equalsIgnoreCase("failed"))
			{
				sumstep.Status = "Failed";
				sumstep.Screenshot = state.Screenshot;
				sumstep.Duration = String.valueOf(Math.round((System.nanoTime() - testStartTime)/1000000000.0));
				sumstep.EndTime = String.valueOf(sdf.format(Calendar.getInstance().getTime()));
				logProcessStepsSum(sumstep, SummaryReportFile);
				return;
			}
		}
		sumstep.Status = "Passed";
		sumstep.Duration = String.valueOf(Math.round((System.nanoTime() - testStartTime)/1000000000.0));
		sumstep.EndTime = String.valueOf(sdf.format(Calendar.getInstance().getTime()));
		logProcessStepsSum(sumstep, SummaryReportFile);
		return;
	}

	//Reading TestSteps from a TestFlow.
	public static ArrayList<ColumnList> readTestFlow(String testFlow) throws FilloException 
	{
		/*Connection connect = ExcelHelper.readWorkbook("C:\\Users\\rvaishnav\\Desktop\\Ecllipse\\Automation Framework\\DataSheet\\DataSheet.xlsx");
		Recordset recordset = ExcelHelper.executeQuery(connect, "Select * from `Test Flow`");
		return ExcelHelper.find(recordset,ColumnName,testFlow);*/
		Connection con = ExcelHelper.readWorkbook(TestFlowFile);
		Recordset rs = ExcelHelper.executeQuery(con,"Select * From \""+TestFlowSheet+"\"");
		ArrayList<ColumnList> arrayList = ExcelHelper.find(rs,"Scenario Name",testFlow);
		//System.out.println(arrayList);
		ExcelHelper.closeConnection(rs,con);
		return arrayList;

	}

	public static ArrayList<ColumnList> readTestCase() throws FilloException
	{
		Connection con = ExcelHelper.readWorkbook(TestCaseFile);
		Recordset rs = ExcelHelper.executeQuery(con,"Select * From \""+TestCaseSheet+"\"");
		ArrayList<ColumnList> arrayList = ExcelHelper.find(rs,"Test Case Name",TestCaseName);
		//System.out.println(arrayList);
		ExcelHelper.closeConnection(rs,con);
		return arrayList;
	}

	//Execute the TestSteps in a TestFlow(This method is called from processTestCase()).
	public static Teststep executeTestStep(ArrayList<ColumnList> testFlowList, HashMap<String, String> testCaseData, String nodeURL) throws Exception
	{
		SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss");
		String prevcondition = "";
		Boolean skipStep = false;
		//Looping through each step in a given TestFlow.
		Teststep sumstep = new Teststep();
		ArrayList<String> listobject = new ArrayList<>();
		//String screenshot = null;
		Teststep step = new Teststep();
		outerloop: for (int i=0; i < testFlowList.size(); i++) 
		{
			if(prevcondition.equals("OR") && previous == true)
			{
				prevcondition = testFlowList.get(i).get(6).trim();
				continue;
			}
			else if(skipStep) {
				if(testFlowList.get(i).get(1).equalsIgnoreCase("TZ")) {
					skipStep = false;
					previous = true;
				}
					
				continue;
			}
			else if(i!=0 && previous == false && !prevcondition.equals("OR")){
				if(testFlowList.get(i).get(1).equalsIgnoreCase("TS")) {
					skipStep = true;
					continue;
				}
				break;
			}
			else
			{
				Result result;
				if(i==0)
					step.TestCaseName = TestCaseName;
				long startTime = System.nanoTime();
				step.StartTime = String.valueOf(sdf.format(Calendar.getInstance().getTime()));
				scenario = testFlowList.get(i).get(0);
				step.TestFlowName = scenario;
				stepNum++;
				step.Steps = "Step " + stepNum;
				action = testFlowList.get(i).get(2);
				step.Action = action;
				object = testFlowList.get(i).get(3);
				condition = testFlowList.get(i).get(6).trim();
				screenshot = testFlowList.get(i).get(7).trim();

				//Obtaining TestData Either from TestCase or DefaultValue
				if(testFlowList.get(i).get(4).equals("Yes") && testCaseData.get(object) != null)
				{
					val[0] = testCaseData.get(object);
				}
				else
				{
					val[0] = testFlowList.get(i).get(5);
					while(Pattern.matches("\\{(.*?)\\}*", val[0]))
					{
						String globaldata = val[0].substring(val[0].indexOf('{')+1, val[0].indexOf('}'));
						val[0] = val[0].replace("{" + globaldata + "}", readGlobalTestData(globaldata));
					}
				}

				ActionType at = ActionType.valueOf(action);
				WebElement ele = null;

				if(testFlowList.get(i).get(1).equals("V"))
				{
					//else// if(action.equals("MatchText") || action.equals("MatchURL"))
					{
						if(!object.startsWith("$$") && !object.equals("BROWSER_URL"))
						{
							listobject = readObjectRepository(object);
							if(listobject == null){
								step.ActualResult = "Object " + object + " could not be found in the datasheet";
								current = false;
								state = current;
								step.Status = "Failed";
								logProcessStepsDet(step, DetailedReportHandle);							
								System.out.println("Object not found");
								break outerloop;
							}
							String[] listvalue = null;			
							listvalue = listobject.get(2).split("\\|");						
							for(int j = 0; j < listvalue.length; j++)
							{
								if(!listobject.get(4).isEmpty())
									ele = findObjects(listobject.get(1), listvalue[j], listobject.get(3), Integer.valueOf(listobject.get(4)));
								else
									ele = findObjects(listobject.get(1), listvalue[j], listobject.get(3));

								if(ele != null)
								{
									break;
								}
							}

							try{							
								ele.getText();	
								highlight(ele);
								if(!at.toString().equalsIgnoreCase("ObjectExists"))
									result = aut.DoAction(at,ele,val,listobject);
								else
								{
									result = new Result(true, "Verify that " + listobject.get(0) + "(" + listobject.get(1) + " = \"" + listobject.get(2) + "\") exists", listobject.get(0) + " should exist", listobject.get(0) + " exists");
								}
								current = result.status;
								step.Action = result.action;
								step.ExpectedResult = result.expresult;
								step.ActualResult = result.result;
								state = current;
							}
							catch(Exception e){
								current = false;
								state = current;
								step.ActualResult = "Object " + listobject.get(0) + "(" + listobject.get(1) + " = \"" + listobject.get(2) + "\") not found on page";
								System.out.println("Ele not found 2");
							}
						}
						else
						{
							result = aut.DoAction(at,val,listobject);
							current = result.status;
							step.Action = result.action;
							step.ExpectedResult = result.expresult;
							step.ActualResult = result.result;
							state = current;
							previous = current;
							prevcondition = condition;
						}
					}

				}
				else if(action.equals("MatchURL") || action.equals("Navigate") || action.equals("MatchTitle")  || action.equals("Wait") || action.equals("SendKeys") || object.equals("BROWSER") || object.isEmpty() || action.equals("OpenBrowser") || action.equals("NavigateBrowser"))
				{
					result = aut.DoAction(at,null,val,listobject);
					current = result.status;
					step.Action = result.action;
					step.ExpectedResult = result.expresult;
					step.ActualResult = result.result;
					state = current;

				}
				else if(action.equals("Open"))
				{
					result = aut.DoAction(at,null,val,listobject, nodeURL);
					current = result.status;
					step.Action = result.action;
					step.ExpectedResult = result.expresult;
					step.ActualResult = result.result;
					state = current;
				}
				else
				{				
					listobject = readObjectRepository(object);
					if(listobject == null){
						step.ActualResult = "Object " + object + " could not be found in the datasheet";
						step.Status = "Failed";
						current = false;
						state = current;
						System.out.println("Object not found");
						logProcessStepsDet(step, DetailedReportHandle);
						break outerloop;
					}
					/*if(listobject == null)
				{
					step.ActualResult = "Object " + object + " could not be found in the datasheet";
					current = false;
					state = current;
					continue;
				}*/
					//objectCol = object.split(",");
					//ele = findObjects(objectCol[1].replaceFirst(" ",""),objectCol[2].replaceFirst(" ",""),objectCol[3].replaceFirst(" ",""));
					String[] listvalue;				
					listvalue = listobject.get(2).split("\\|");
					for(int j = 0; j < listvalue.length; j++)
					{
						if(!listobject.get(4).isEmpty())
							ele = findObjects(listobject.get(1), listvalue[j], listobject.get(3), Integer.valueOf(listobject.get(4)));
						else
							ele = findObjects(listobject.get(1), listvalue[j], listobject.get(3));

						/*if(!ele.equals(null))				
					continue;*/

						if(ele != null){
							break;
						}
						
					}

					try
					{
						ele.getText();
						highlight(ele);
						System.out.println();
						result = aut.DoAction(at,ele,val,listobject);
						current = result.status;
						step.Action = result.action;
						step.ExpectedResult = result.expresult;
						step.ActualResult = result.result;
						step.ActualResult = result.result;
						state = current;
					}
					catch(Exception e)
					{
						current = false;
						state = current;
						step.ActualResult = "Object " + listobject.get(0) + "(" + listobject.get(1) + " = \"" + listobject.get(2) + "\") not found";
						//continue;
					}
					/*if(ele.equals(null)){
					}*/

				}

				if(screenshot.equals("Yes"))
				{
					step.Screenshot = captureScreenshot(String.valueOf(stepNum));
					//step.Screenshot = ResultsFolder + "/Screenshots/Step " + String.valueOf(stepNum) + ".png";
				}
				else if(state == false)
				{
					step.Screenshot = captureScreenshot(String.valueOf(stepNum));
					screenshot = step.Screenshot;
					//sumstep.Screenshot = step.Screenshot;
					//step.Screenshot = ResultsFolder + "/Screenshots/Step " + String.valueOf(stepNum) + ".png";
					//state = true;
				}
				System.out.println("Step No:"+(i+1)+state);
				long endTime = System.nanoTime();
				step.EndTime = String.valueOf(sdf.format(Calendar.getInstance().getTime()));
				System.out.println("End Time: "+sdf.format(Calendar.getInstance().getTime()));
				long elapsedTime = endTime - startTime;			
				double seconds = (double)elapsedTime/1000000000.0;
				//step.EndTime = String.valueOf(sdf.format(Calendar.getInstance().getTime()));
				System.out.println("Elapsed Time: "+ Math.round(seconds));
				step.Duration = String.valueOf(Math.round(seconds));

				if(current)
					step.Status = "Passed";
				else
					step.Status = "Failed";
				if(condition.equalsIgnoreCase("OR") && step.Status.equalsIgnoreCase("Failed")){
				}
				else{
					logProcessStepsDet(step, DetailedReportHandle);
					previous = current;
					prevcondition = condition;
				}
				if(current == false && !condition.equalsIgnoreCase("OR") && !testFlowList.get(i).get(1).equalsIgnoreCase("IF"))
				{
					break;
				}
			}
		}
		//screenshot = "junk";
		sumstep.Status = state == true ? "Passed" : "Failed";
		return sumstep;
	}

	//Reading the ObjectRepository sheet.
	public static ArrayList<String> readObjectRepository(String ObjectName) throws FilloException 
	{
		Connection connect = null;
		Recordset record = null;
		try
		{
			connect = ExcelHelper.readWorkbook(ObjectRepoFile);
			record = ExcelHelper.executeQuery(connect, "select * from \"Object Repository\"");
			return ExcelHelper.findRow(record, "Object Name", ObjectName);
		}
		catch(Exception e)
		{
			return null;
		}
	}

	//Reading GlobalTestData sheet.
	public static String readGlobalTestData(String ObjectName) throws FilloException 
	{
		Connection connect = null;
		Recordset record = null;

		connect = ExcelHelper.readWorkbook(GlobalDataFile);
		record = ExcelHelper.executeQuery(connect, "select * from \"Global Test Data\"");
		return ExcelHelper.findRow(record, "Test Data", ObjectName).get(1);
	}

	//Reading the TestData from TestCases.
	/*public static String readTestData(String ObjectName) throws FilloException 
	{

		Connection connect = null;
		Recordset record = null;

		connect = ExcelHelper.readWorkbook("C:\\Users\\rvaishnav\\Desktop\\Ecllipse\\Automation Framework\\DataSheet\\DataSheet.xlsx");
		record = ExcelHelper.executeQuery(connect, "select * from `Test Cases`");
		return ExcelHelper.findRow(record, "Object Name", ObjectName).toString();
	}*/

	//Identifying the WebElement objects(This method is called from executeTestStep()).
	public static WebElement findObjects(String idKey, String idValue1, String tagName, int index) 
	{
		//boolean elementFound;
		
		aut.waitForLoad(aut.browser);
		if(aut.browser.getWindowHandles().size() > 1)
		aut.closeAllWindowsBut();
		String idValue = idValue1;
		List<WebElement> element = new ArrayList<WebElement>();
		if (tagName.isEmpty()) 
		{
			tagName = "*";
		}
		if (index < 0) 
		{
			index = 0;
		}
		
		if(idKey.trim().isEmpty()){
			try
			{
				element = aut.browser.findElements(By.xpath("//"+tagName));
				System.out.println(element.get(0).getText());
			}
			catch(Exception e){
				
			}
		}
		else if((idValue.startsWith("%") || idValue.startsWith(".*")) && !(idValue.endsWith("%")))
		{
			if(idValue.startsWith("%"))
				idValue = idValue.replaceFirst("%","");
			else
				idValue = idValue.replace(".*","");
			element = aut.browser.findElements(By.xpath("//"+tagName+"[substring(@"+idKey+", string-length(@"+idKey+") - string-length(\""+idValue+"\") +1) = \""+idValue+"\"]"));
			//element = aut.browser.findElements(By.xpath("//"+tagName+"[contains(@"+idKey+",\""+idValue+"\")]"));
			for(int i=0;i<element.size();i++){
				//highlight(element.get(i));
				System.out.println(element.get(i).getAttribute(idKey));
				//if(element.get(i).getAttribute(idKey).endsWith(idValue))
				System.out.println("Web Element"+i+":"+element.get(i).getText());
			}
			/*try{
				System.out.println(element.get(0).getText());
			}
			catch(Exception e){
				return null;
			}*/
		}
		else if(!(idValue.startsWith("%")) && idValue.endsWith("%"))
		{
			idValue = idValue.substring(0,idValue.indexOf("*"));
			element = aut.browser.findElements(By.xpath("//"+tagName+"[starts-with(@"+idKey+",\""+idValue+"\")]"));
			System.out.println("Elements size:"+element.size());
			for(int i=0;i<element.size();i++)
				System.out.println("Web Element"+i+":"+element.get(i).getText());
		}
		else if(idValue.contains("%"))
		{
			idValue = idValue.replaceAll("%","");
			element = aut.browser.findElements(By.xpath("//"+tagName+"[contains(@"+idKey+",\""+idValue+"\")]"));
			System.out.println("Elements size:"+element.size());
			for(int i=0;i<element.size();i++)
				System.out.println("Web Element"+i+":"+element.get(i).getText());
		}
		else if(idKey.equalsIgnoreCase("innertext")){
			System.out.println(idValue);
			try{
				element = aut.browser.findElements(By.xpath("//"+tagName+"[contains(text(),\""+idValue+"\")]"));
			}
			catch(Exception v)
			{
				//return null;
			}
		}
		else {
			System.out.println(idKey);
			System.out.println(idValue);
			try
			{
				element = aut.browser.findElements(By.xpath("//"+tagName+"[contains(@"+idKey+",\""+idValue+"\")]"));
				System.out.println(element.get(0).getText());
			}
			catch(Exception e)
			{
				
				//element = aut.browser.findElements(By.xpath("//"+tagName+"[text()[contains(.,'"+idValue+"')]]"));
			}
		}


		if(element.size() > 0){
			List<WebElement> ele = element;
			if(ele.size() > 1 && index != 0){
				int j = 0;
				for(j = 0; j < element.size(); j++){
					try{
						if(element.get(j).isDisplayed()){
							return element.get(j);
						}
					}			
					catch (Exception d){
						d.printStackTrace();
						//if(d.toString().contains("Stale"))
						element.remove(j);
						--j;
					}
				}
			}
			return ele.get(index);
		}
		else if(retryFind){
			System.out.println("Retrying object identification...");
			//aut.DoAction(ActionType.Wait, new String[] {"5"});
			retryFind = false;
			WebElement ele = findObjects(idKey, idValue1, tagName, index);
			retryFind = true;
			if(ele == null){
				System.out.println("Didn't find on retry either");
				return null;
			}
			System.out.println("Methinks we got 'un");
			return ele;
		}
		else if(idKey.equalsIgnoreCase("innertext")){
			System.out.println("Performing last resort...");
			List<WebElement> ele = aut.browser.findElements(By.tagName(tagName));
			for(int i=0;i<ele.size();i++){
				//highlight(element.get(i));
				try{
					if(ele.get(i).getText().trim().equalsIgnoreCase(idValue)){
						element.add(ele.get(i));
						//if(element.get(i).getAttribute(idKey).endsWith(idValue))
						System.out.println("Web Element"+i+":"+element.get(i).getText());
					}

				}
				catch(Exception e){
					try{
						if(ele.get(i).getAttribute("innerText").trim().equalsIgnoreCase(idValue)){
							element.add(ele.get(i));
							//if(element.get(i).getAttribute(idKey).endsWith(idValue))
							System.out.println("Web Element"+i+":"+element.get(i).getText());
						}
					}
					catch(Exception d){
						continue;
					}					
				}
			}
			if(element.size() > 0){
				return element.get(index);
			}
		}
		else{
			return null;
		}
		return null;
	}



	public static WebElement findObjects(String idKey, String idValue) 
	{
		return findObjects(idKey, idValue, "");
	}

	public static WebElement findObjects(String idKey, String idValue, String tagName) 
	{
		return findObjects(idKey, idValue, tagName, -1);
	}

	//Highlight the identified WebElement object(This method is called from executeTestStep()).
	public static void highlight(WebElement element) 
	{
		for (int i = 0; i < 2; i++) 
		{
			try{
				JavascriptExecutor js = (JavascriptExecutor) aut.browser;
				js.executeScript("arguments[0].setAttribute('style', arguments[1]);", element,
						"color: yellow; border: 2px solid yellow;");
				try 
				{
					Thread.sleep(25);
				}
				catch (InterruptedException e) 
				{
					e.printStackTrace();
				}
				js.executeScript("arguments[0].setAttribute('style', arguments[1]);", element, "");
				try
				{
					Thread.sleep(25);
				}
				catch (InterruptedException e) 
				{
					e.printStackTrace();
				}
			}
			catch (Exception e){
				e.printStackTrace();
				continue;
			}
		}
	}
	/*Methods required for TestCase execution ends here*/

	/*Methods required for ReportGeneration starts here*/
	//Screenshot.
	public static void LogReportScreenshot(String TestcaseName, String StepNumber ,String ScreenShotfilepath) throws Exception
	{
		/*File file = new File(Main.ScreenShotsSaveLocation);
		file.mkdir();*/
		File file = new File(MainTest.ScreenShotsSaveLocation + "\\" +TestcaseName);
		file.mkdir();
		File imageURL = new File(ScreenShotfilepath);
		BufferedImage saveImage = ImageIO.read(imageURL);
		ImageIO.write(saveImage,"jpg", new File(MainTest.ScreenShotsSaveLocation + "\\" +TestcaseName + "\\"+ StepNumber + ".jpg"));
		System.out.println("Success " +StepNumber);
	}

	//Captures Screenshot
	public static String captureScreenshot(String stepnum) throws Exception 
	{
		try
		{
			File scrFile = ((TakesScreenshot)aut.browser).getScreenshotAs(OutputType.FILE);
			//DateTimeFormatter dtf = DateTimeFormatter.ofPattern("MM_dd_yyyy_HH_mm_ss_a");
			//LocalDateTime now = LocalDateTime.now();
			//String cal = dtf.format(now).toString();
			String path = ResultsFolder+"/Screenshots/" + TestCaseName + "/Step "+stepnum+".png";
			FileUtils.copyFile(scrFile, new File(path));
			System.out.println("Screenshot captured!");
			return path;
		}
		catch(Exception e)
		{
			System.out.println("Unable to capture screenshot");
		}
		return null;
	}

	//Creates a Detailed Report.
	public static void logDetailedReportTitle(String shandle) throws Exception
	{
		String testRunName = TestRunName; 
		String executedBy = ExecutedBy;
		DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
		Date date = new Date();
		String executionDate = dateFormat.format(date);
		String operatingSystem = System.getProperty("os.name");
		String systemType = System.getProperty("os.arch");
		String version = "1.0";
		String systemName = java.net.InetAddress.getLocalHost().getHostName();

		WritableSheet sheet = ExcelHelper.getObject(shandle);
		Range r[];
		r = sheet.getMergedCells();

		if(r.length>0)
		{
			for(int i=0;i<r.length;i++)
				sheet.unmergeCells(r[i]);
		}

		wFont = new WritableFont(font,23,WritableFont.BOLD);
		wFont.setPointSize(14);
		wFont.setColour(Colour.BLACK);
		wm =new WritableCellFormat(wFont);
		wm.setVerticalAlignment(VerticalAlignment.CENTRE);
		wm.setLocked(false);
		wm.setWrap(true);
		wm.setAlignment(Alignment.CENTRE);
		wm.setBackground(Colour.GREY_50_PERCENT);
		ExcelHelper.writeFormattedText(shandle, 0, 0, "Test Run Name - " + testRunName, wm);
		sheet.mergeCells(0, 0, 11, 0);
		sheet.setRowView(0, 24*20);

		wFont = new WritableFont(font, 23,WritableFont.BOLD);
		wFont.setPointSize(12);
		wFont.setColour(Colour.BLACK);
		wm =new WritableCellFormat(wFont);
		wm.setVerticalAlignment(VerticalAlignment.CENTRE);
		wm.setLocked(false);
		wm.setWrap(true);
		wm.setAlignment(Alignment.CENTRE);
		wm.setBackground(Colour.GREY_40_PERCENT);
		ExcelHelper.writeFormattedText(shandle, 0, 1, "Executed By - " + executedBy + ", Execution Date - " + executionDate, wm);
		sheet.mergeCells(0, 1, 11, 1);
		sheet.setRowView(1, 18*20);

		wFont = new WritableFont(font, 23,WritableFont.BOLD);
		wFont.setPointSize(12);
		wFont.setColour(Colour.BLACK);
		wm =new WritableCellFormat(wFont);
		wm.setVerticalAlignment(VerticalAlignment.CENTRE);
		wm.setLocked(false);
		wm.setWrap(true);
		wm.setAlignment(Alignment.CENTRE);
		wm.setBackground(Colour.GRAY_25);
		ExcelHelper.writeFormattedText(shandle, 0, 2, "ENVIRONMENT DETAILS: Operating System - "+ operatingSystem + "; System Type - " + systemType + "; Version -" + version + "; System Name - " + systemName, wm);
		sheet.mergeCells(0, 2, 11, 2);
		sheet.setRowView(2, 24*20);

		/*wFont = new WritableFont(font,23,WritableFont.NO_BOLD);
		wFont.setPointSize(11);
		wFont.setColour(Colour.BLACK);
		wm =new WritableCellFormat(wFont);
		wm.setVerticalAlignment(VerticalAlignment.JUSTIFY);
		wm.setLocked(false);
		wm.setWrap(true);
		wm.setAlignment(Alignment.LEFT);
		wm.setBackground(Colour.WHITE);
		ExcelHelper.writeFormattedText(shandle, 0, 3, "Operating System - " + operatingSystem + "\n" + "System Type - " + systemType + "\n" + "Version -" + version + "\n" + "System Name - " + systemName, wm);
		sheet.mergeCells(0, 3, 11, 3);
		sheet.setRowView(3, 60*20);*/

		wFont = new WritableFont(font,23,WritableFont.BOLD);
		wFont.setPointSize(12);
		wFont.setColour(Colour.BLACK);
		wm =new WritableCellFormat(wFont);
		wm.setVerticalAlignment(VerticalAlignment.CENTRE);
		wm.setLocked(false);
		wm.setWrap(true);
		wm.setAlignment(Alignment.CENTRE);
		wm.setBackground(Colour.GREY_40_PERCENT);
		ExcelHelper.writeFormattedText(shandle, 0, 3, "TEST RESULTS", wm);
		sheet.mergeCells(0, 3, 11, 3);    
		sheet.setRowView(3, 24*20);

	}

	//Creates a Summary Report.
	public static void logSummaryReportTitle(String shandle) throws Exception
	{
		String testRunName = TestRunName; 
		String executedBy = ExecutedBy;
		DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
		Date date = new Date();
		String executionDate = dateFormat.format(date);
		String operatingSystem = System.getProperty("os.name");
		String systemType = System.getProperty("os.arch");
		String version = "1.0";
		String systemName = java.net.InetAddress.getLocalHost().getHostName();

		WritableSheet sheet = ExcelHelper.getObject(shandle);
		Range r[];
		r = sheet.getMergedCells();
		if(r.length>0)
		{
			for(int i=0;i<r.length;i++)
				sheet.unmergeCells(r[i]);
		}
		wFont = new WritableFont(font,23,WritableFont.BOLD);
		wFont.setPointSize(14);
		wFont.setColour(Colour.BLACK);
		wm =new WritableCellFormat(wFont);
		wm.setVerticalAlignment(VerticalAlignment.CENTRE);
		wm.setLocked(false);
		wm.setWrap(true);
		wm.setAlignment(Alignment.CENTRE);
		wm.setBackground(Colour.GREY_50_PERCENT);
		ExcelHelper.writeFormattedText(shandle, 0, 0, "Test Run Name - " + testRunName, wm);
		sheet.mergeCells(0, 0, 7, 0);
		sheet.setRowView(0, 24*20);

		wFont = new WritableFont(font, 23,WritableFont.BOLD);
		wFont.setPointSize(12);
		wFont.setColour(Colour.BLACK);
		wm =new WritableCellFormat(wFont);
		wm.setVerticalAlignment(VerticalAlignment.CENTRE);
		wm.setLocked(false);
		wm.setWrap(true);
		wm.setAlignment(Alignment.CENTRE);
		wm.setBackground(Colour.GREY_40_PERCENT);
		ExcelHelper.writeFormattedText(shandle, 0, 1, "Executed By - " + executedBy + ", Execution Date - " + executionDate, wm);
		sheet.mergeCells(0, 1, 7, 1);
		sheet.setRowView(1, 18*20);

		wFont = new WritableFont(font, 23,WritableFont.BOLD);
		wFont.setPointSize(12);
		wFont.setColour(Colour.BLACK);
		wm =new WritableCellFormat(wFont);
		wm.setVerticalAlignment(VerticalAlignment.CENTRE);
		wm.setLocked(false);
		wm.setWrap(true);
		wm.setAlignment(Alignment.CENTRE);
		wm.setBackground(Colour.GRAY_25);
		ExcelHelper.writeFormattedText(shandle, 0, 2, "ENVIRONMENT DETAILS: Operating System - " + operatingSystem + "; System Type - " + systemType + "; Version - " + version + "; System Name - " + systemName, wm);
		sheet.mergeCells(0, 2, 7, 2);
		sheet.setRowView(2, 24*20);

		/*wFont = new WritableFont(font,23,WritableFont.NO_BOLD);
		wFont.setPointSize(11);
		wFont.setColour(Colour.BLACK);
		wm =new WritableCellFormat(wFont);
		wm.setVerticalAlignment(VerticalAlignment.JUSTIFY);
		wm.setLocked(false);
		wm.setWrap(true);
		wm.setAlignment(Alignment.LEFT);
		wm.setBackground(Colour.WHITE);
		ExcelHelper.writeFormattedText(shandle, 0, 3, "Operating System - " + operatingSystem + "\n" + "System Type - " + systemType + "\n" + "Version -" + version + "\n" + "System Name - " + systemName, wm);
		sheet.mergeCells(0, 3, 7, 3);
		sheet.setRowView(3, 60*20);*/

		wFont = new WritableFont(font,23,WritableFont.BOLD);
		wFont.setPointSize(12);
		wFont.setColour(Colour.BLACK);
		wm =new WritableCellFormat(wFont);
		wm.setVerticalAlignment(VerticalAlignment.CENTRE);
		wm.setLocked(false);
		wm.setWrap(true);
		wm.setAlignment(Alignment.CENTRE);
		wm.setBackground(Colour.GREY_40_PERCENT);
		ExcelHelper.writeFormattedText(shandle, 0, 3, "TEST RESULTS", wm);
		sheet.mergeCells(0, 3, 7, 3);     
		sheet.setRowView(3, 24*20);

	}

	//Creates Summary Column Headers.
	public static void writeSummaryColumnHeaders(String shandle) throws Exception
	{
		wFont = new WritableFont(font, 12, WritableFont.BOLD);

		wm = new WritableCellFormat(wFont);
		wm.setVerticalAlignment(VerticalAlignment.CENTRE);
		wm.setAlignment(Alignment.CENTRE);
		wm.setBackground(Colour.GREY_25_PERCENT);
		for (int i=0;i<summaryHeaders.length;i++)
		{
			ExcelHelper.writeFormattedText(shandle,i,4,summaryHeaders[i], wm);
		}
	}

	//Creates Detailed Column Headers.
	public static void writeDetailedColumnHeaders(String shandle) throws Exception
	{
		wFont = new WritableFont(font, 12, WritableFont.BOLD);
		wm = new WritableCellFormat(wFont);
		wm.setVerticalAlignment(VerticalAlignment.CENTRE);
		wm.setLocked(false);
		wm.setWrap(true);
		wm.setAlignment(Alignment.CENTRE);
		wm.setBackground(Colour.GREY_25_PERCENT);
		for (int i=0;i<detailedHeaders.length;i++)
		{
			ExcelHelper.writeFormattedText(shandle,i,4,detailedHeaders[i], wm);
		}
	}

	public static WritableFont getCellFormat(Teststep step) throws Exception 
	{
		WritableFont font = new WritableFont(WritableFont.createFont("Calibri"), 11);
		Colour colour;
		switch (step.Status) {
		case "Blocked":
			colour = Colour.ORANGE;
			break;
		case "Failed":
			colour = Colour.RED;
			break;
		case "InProgress":
			colour = Colour.BLUE;
			break;
		case "Passed":
			colour = Colour.GREEN;
			break;
		default:
			colour = Colour.BLACK;
			break;
		}
		font.setColour(colour);
		return new WritableFont(font);
	}

	//Provides details on cosmetic information for the data.
	public static void fillRow(Colour color, String filePath) throws Exception{
		File file = new File(filePath);
		ExcelHelper.OpenWorkbook(file, "fillRow");
		String sh = ExcelHelper.openSheet("fillRow", "Sheet1");
		int row = ExcelHelper.getLastRow("", sh);
		WritableFont wm = new WritableFont(WritableFont.TIMES, 11);
		ExcelHelper.writeFormattedText(sh, 0, row, "", Alignment.LEFT, color, wm);
		WritableSheet sheet = (WritableSheet) ExcelHelper.getObject(sh);
		sheet.mergeCells(0, row, 11, row);
		//label.setCellFormat();
		ExcelHelper.closeSheet("", sh);
		ExcelHelper.CloseWorkbook("fillRow");
	
	}

	//Creates hyper-link for the screenshot.
	public static void screenshot(String shandler, int col, int testStepIndex,String filepath) throws Exception 
	{
		WritableSheet writablesheet2 = (WritableSheet) ExcelHelper.DictionaryObj.get(shandler);
		WritableHyperlink hlk = new WritableHyperlink(col, testStepIndex,new File(filepath), "screenshot");
		writablesheet2.addHyperlink(hlk);
	}

	public static void logProcessStepsDet(Teststep step, String whandle) throws Exception 
	{
		//int count = 0;
		File fileobj = new File(DetailedReportFile);
		ExcelHelper.OpenWorkbook(fileobj, whandle);
		int testStepIndex;
		//String wh = 
		/*
		wm.setBackground(Colour.GREY_40_PERCENT);
		ExcelHelper.writeFormattedText(shandle, 0, 4, "TEST RESULTS", wm);
		sheet.mergeCells(0, 4, 11, 4);    
		sheet.setRowView(4, 24*20);
		 */
		String sh = ExcelHelper.openSheet(whandle, "Sheet1");
		testStepIndex = ExcelHelper.getLastRow("", sh);
		WritableFont font = getCellFormat(step);
		if(detailedCount == 0)
			ExcelHelper.writeFormattedText(sh, 0, testStepIndex, step.TestCaseName,Alignment.LEFT, null, font);
		ExcelHelper.writeFormattedText(sh, 1, testStepIndex, step.TestFlowName,Alignment.LEFT, null, font);
		ExcelHelper.writeFormattedText(sh, 2, testStepIndex, step.Steps, Alignment.LEFT,null, font);
		ExcelHelper.writeFormattedText(sh, 3, testStepIndex, step.Action, Alignment.LEFT,null, font);
		ExcelHelper.writeFormattedText(sh, 4, testStepIndex, step.ExpectedResult,Alignment.LEFT, null, font);
		ExcelHelper.writeFormattedText(sh, 5, testStepIndex, step.ActualResult,Alignment.LEFT, null, font);

		if (!step.Screenshot.isEmpty()) {
			screenshot(sh, 6, testStepIndex, step.Screenshot);
		}

		ExcelHelper.writeFormattedText(sh, 7, testStepIndex, step.Status, Alignment.LEFT,null, font);
		ExcelHelper.writeFormattedText(sh, 8, testStepIndex, step.ExecutionDate,Alignment.LEFT, null, font);
		ExcelHelper.writeFormattedText(sh, 9, testStepIndex, step.StartTime,Alignment.LEFT, null, font);
		ExcelHelper.writeFormattedText(sh, 10, testStepIndex, step.EndTime, Alignment.LEFT,null, font);
		ExcelHelper.writeFormattedText(sh, 11, testStepIndex, step.Duration,Alignment.LEFT, null, font);
		ExcelHelper.autoFit(sh);
		//testStepIndex++;
		ExcelHelper.closeSheet("", sh);
		ExcelHelper.CloseWorkbook(whandle);
		detailedCount++;
	}

	//Writes the details of each step during the TestStep execution(This method is called from executeTestStep).
	public static void logProcessStepsSum(Teststep step, String whandle) throws Exception 
	{
		File fileobj = new File(SummaryReportFile);
		String wh = ExcelHelper.OpenWorkbook(fileobj, whandle);
		String sh = ExcelHelper.openSheet(whandle, "Sheet1");
		int testStepIndex = ExcelHelper.getLastRow("", sh);
		WritableFont font = getCellFormat(step);

		ExcelHelper.writeFormattedText(sh, 0, testStepIndex, step.TestCaseName,Alignment.LEFT, null, font);
		ExcelHelper.writeFormattedText(sh, 1, testStepIndex, step.Status, Alignment.LEFT,null, font);

		if (!step.Screenshot.isEmpty()) 
		{
			screenshot(sh, 2, testStepIndex, step.Screenshot);
		}

		ExcelHelper.writeFormattedText(sh, 3, testStepIndex, step.ExecutionDate, Alignment.LEFT, null, font);
		ExcelHelper.writeFormattedText(sh, 4, testStepIndex, step.StartTime, Alignment.LEFT, null, font);
		ExcelHelper.writeFormattedText(sh, 5, testStepIndex, step.EndTime, Alignment.LEFT, null, font);
		ExcelHelper.writeFormattedText(sh, 6, testStepIndex, step.Duration, Alignment.LEFT, null, font);
		ExcelHelper.writeFormattedText(sh, 7, testStepIndex, step.Comments, Alignment.LEFT, null, font);
		//testStepIndex++;
		ExcelHelper.autoFit(sh);
		ExcelHelper.closeSheet("", sh);
		ExcelHelper.CloseWorkbook(whandle);
	}

	//Creating a file for Detailed Report.
	public static void CreateDetailedReport(String Filename) throws Exception 
	{
		File fileobj = new File(Filename);
		String DetailedReport = ExcelHelper.OpenWorkbook(fileobj, DetailedReportHandle);
	}

	//Creating a file for Summary Report.
	public static void CreateSummaryReport(String Filename) throws Exception 
	{
		File fileobj = new File(Filename);
		String SummaryReport = ExcelHelper.OpenWorkbook(fileobj,SummaryReportHandle);
	}

	//Closes the Report.
	public static void CloseReport(String whandle) throws Exception 
	{
		ExcelHelper.CloseWorkbook(whandle);
	}
}
