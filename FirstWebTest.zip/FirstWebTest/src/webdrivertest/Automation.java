package webdrivertest;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLDecoder;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import java.util.regex.Pattern;

import org.openqa.selenium.By;
import org.openqa.selenium.Capabilities;
import org.openqa.selenium.Cookie;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Parameters;

public class Automation {

	BrowserType browserType;
	RemoteWebDriver browser;
	String mainWindowHandle;
	Set<Cookie> allCookies;
	public String nodeUrl;
	
	public void Open(String nodeUrl) throws NullPointerException, UnsupportedEncodingException {
		System.out.println("Open() : " + nodeUrl);
		initialize(browserType, nodeUrl);
	}

	public WebElement GetControl(String attribute, String value, String tag, int index) {

		if (attribute.isEmpty() || value.isEmpty()) {
			System.out.printf("Control: %s or value: %s cannot be empty%n", attribute, value);
			Close();
		}

		WebElement control = null;

		String expression = "";

		tag = tag.isEmpty() ? "*" : tag.trim();
		index = index < 0 ? 0 : index;

		expression = expression.replace("identifier", attribute);
		expression = expression.replace("value", value);
		expression = expression.replace("tag", tag);
		List<WebElement> controlList = browser.findElements(By.xpath(expression));

		if (controlList.size() > index)
			control = controlList.get(index);

		verifyControl(control, expression, attribute, value);
		return control;
	}

	public WebElement GetControl(String attribute, String value, String tag) {
		return GetControl(attribute, value, tag, 0);
	}

	public WebElement GetControl(String attribute, String value) {
		return GetControl(attribute, value, "*");
	}

	public WebElement GetControlByText(String value, String tag, int index) {
		if (value.isEmpty()) {
			System.out.println("Value cannot be empty");
			Close();
		}

		WebElement control = null;

		String expression = "//*regexp:matches[@value='text']";

		tag = tag.isEmpty() ? "*" : tag.trim();
		index = index < 0 ? 0 : index;

		expression = expression.replace("text", value);
		expression = expression.replace("tag", tag);
		List<WebElement> controlList = browser.findElements(By.xpath(expression));

		if (controlList.size() > index)
			control = controlList.get(index);

		verifyControl(control, expression, "value", value);
		return control;
	}

	public Result DoAction(ActionType action, WebElement control, String[] parameters, ArrayList<String> listobject) {
		try {
			switch (action) {
			case Click:
				return click(control, listobject);
			case RightClick:
				return rightClick(control, listobject);
			case OnMouseOver:
				return onMouseOver(control, listobject);
			case Navigate:
				return navigate(parameters, listobject);
			case Open:
				System.out.println("Do Action: " + nodeUrl);
				return open(parameters, nodeUrl);
			case SetText:
				return setText(control, parameters, listobject);
			case MatchDate:
				return matchDate(control, parameters, listobject);
			case MatchPartialText:
				return matchText(control, parameters, listobject);
			case MatchText:
				return control == null ? matchBrowserVersion(parameters) : matchText(control, parameters, listobject);
			case MatchTitle:
				return matchTitle(parameters);
			case MatchURL:
				return matchUrl(control,parameters);
			case Wait:
				return waitForTimeOut(parameters);
			case MatchExactText:
				return matchExactText(control, parameters, listobject);
			case SelectByValue:
				return selectByValue(control, parameters, listobject);
			case SelectByIndex:
				return selectByIndex(control, parameters, listobject);
			case ObjectExists:
				return objectExists(control, parameters, listobject);
			case IsEmpty:
				return isEmpty(control, listobject);
			case IsEnabled:
				return isEnabled(control, listobject);
			case GetListOfItems:
				return getListOfItems(control, parameters, listobject);
			case Close:
				return Close(); //return true;
			case SetTextbySendKeys:
				return sendKeys(parameters, listobject);
			case SendKeys:
				return sendKeys(parameters, listobject);
			case SetCheck:
				return setCheck(control, parameters, listobject);
			case SaveWebPage:
				return saveWebPage(parameters);
			case WebTable:
				return webTable(control, parameters, listobject);
			default:
				return new Result(false, "", "", action.toString() + " action has not been defined");
			}
		} catch (Exception e) {
			e.printStackTrace();
			return new Result(false, "", "", e.toString());
		}		

	}

	public Result DoAction(ActionType action, String[] parameters, ArrayList<String> listobject) {
		return DoAction(action, null, parameters, listobject);
	}
	public Result DoAction(ActionType action, WebElement control, String[] parameters, ArrayList<String> listobject, String nodeURL) {
		nodeUrl = nodeURL;
		return DoAction(action, null, parameters, listobject);
	}
	public Result DoAction(ActionType action, WebElement control, ArrayList<String> listobject) {
		return DoAction(action, control, null, listobject);
	}

	private Result isEnabled(WebElement control, ArrayList<String> listobject) {
		String actionText = "Verify that " + listobject.get(0) + "(" + listobject.get(1) + " = \"" + listobject.get(2) + "\") is enabled";
		String expresult = listobject.get(0) + " should be enabled";
		String result = listobject.get(0) + " is enabled";
		boolean res = control.isEnabled();
		if(res){
			return new Result(true, actionText, expresult, result);
		}
		else{
			return new Result(false, actionText, expresult, "Element is disabled");
		}
	}

	public Result saveWebPage(String[] parameters) {
		String actionText = "Save the web page source to " + parameters[0];
		String expresult = "Web page source should be saved to " + parameters[0];
		String result = "Web page source is saved to " + parameters[0];
		String str = browser.getPageSource();
		BufferedWriter writer;
		try {
			writer = new BufferedWriter(new FileWriter(parameters[0], true));		
			writer.write(str);		     
			writer.close();
			return new Result(true, actionText, expresult, result);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return new Result(false, actionText, expresult, "IO error has occurred");
		}
		catch (Exception e){
			return new Result(false, actionText, expresult, "Unknown error has occurred");
		}

	}

	public Result onMouseOver(WebElement control, ArrayList<String> listobject) {
		String actionText = "Move mouse to " + listobject.get(0) + "(" + listobject.get(1) + " = \"" + listobject.get(2) + "\")";
		String expresult = "Mouse should be moved to "+ listobject.get(0);
		String result = "Mouse is moved to "+ listobject.get(0);
		Actions builder = new Actions(browser);
		try{
			builder.moveToElement(control).perform();
			return new Result(true, actionText, expresult, result);
		}
		catch(Exception e){
			return new Result(false, actionText, expresult, e.toString());
		}
	}

	public Result rightClick(WebElement control, ArrayList<String> listobject) {
		String actionText = "Perform right click on " + listobject.get(0) + "(" + listobject.get(1) + " = \"" + listobject.get(2) + "\")";
		String expresult = listobject.get(0) + " should be right clicked";
		String result = listobject.get(0) + " is right clicked";
		// TODO Auto-generated method stub
		Actions builder = new Actions(browser);
		try{
			builder.contextClick(control).perform();
			return new Result(true, actionText, expresult, result);
		}
		catch(Exception e){
			return new Result(false, actionText, expresult, e.toString());
		}
	}

	public Result webTable(WebElement control, String[] parameters, ArrayList<String> listobject){
		
		String actionText = "Verify that the contents of table object " + listobject.get(0) + "(" + listobject.get(1) + " = \"" + listobject.get(2) + "\") match test data";
		String expresult = "Contents of table " + listobject.get(0) + " should match test data";
		String result = "Contents of table " + listobject.get(0) + " match test data";
		parameters = parameters[0].split(",");
		parameters = parameters[0].split(";");
		WebElement row = control.findElement(By.xpath("//*[contains(text(),\"" + parameters[0] + "\")]"));
		for(int i=0; i<parameters.length; i++){
			WebElement match = row.findElement(By.xpath("//td|th[.=\"" + parameters[i] + "\"]"));
			highlightControl(match);
			if(match == null)
				return new Result(false, actionText, expresult, "Table headers do not match test data");
		}	

		return new Result(true, actionText, expresult, result);

	}


	public Result setCheck(WebElement control, String[] parameters, ArrayList<String> listobject) {
		String actionText = "Set the checkbox "  + listobject.get(0) + "(" + listobject.get(1) + " = \"" + listobject.get(2) + "\") to " + parameters[0];
		String expresult = listobject.get(0) + " should be set to " + parameters[0];
		String result = listobject.get(0) + " is set to " + parameters[0];
		// TODO Auto-generated method stub
		if(!control.isSelected() && parameters[0].equalsIgnoreCase("On") || control.isSelected() && parameters[0].equalsIgnoreCase("Off"))
			try{				
				control.click();
				return new Result(true, actionText, expresult, result);
			}
		catch(Exception e){

			try{					
				JavascriptExecutor js = (JavascriptExecutor)browser;
				js.executeScript("arguments[0].click();", control);
				return new Result(true, actionText, expresult, result);
			}

			catch(Exception d){
				System.out.println(d.toString());
				return new Result(false, actionText, expresult, d.toString());
			}
		}
		return new Result(true, actionText, expresult, result);
	}


	Result matchBrowserVersion(String[] parameters) {
		
		String actionText = "Check browser version";
		String expresult = "Browser version should be " + parameters[0];
		String result = "Browser version is " + parameters[0];
		// Check if the parameter array contains the required values
		if (!parameterCheck(parameters, 1))
			return new Result(false, actionText, expresult, "Required values were not passed");

		// Change the actual and expected text to lower case to ignore casing
		String expectedValue = parameters[0].trim().toLowerCase();
		Capabilities browserCapabilities = ((RemoteWebDriver) browser).getCapabilities();
		String actualValue = browserCapabilities.getBrowserName() + " " + browserCapabilities.getVersion();
		System.out.println(actualValue);

		if (matchGenericText(expectedValue, actualValue)) {
			System.out.println("Control Text matched with " + expectedValue);
			return new Result(true, actionText, expresult, result);
		} else
			return new Result(false, actionText, expresult, "Browser version does not match with " + parameters[0]);
	}

	public Result Close()
	{

		Set<Cookie> allCookies = browser.manage().getCookies();
		browser.close();
		browser.quit();
		browser = null;
		browserType = null;
		//System.exit(0);
		return new Result(true, "Close the browser", "Browser should be closed", "Browser is closed");
	}

	void setBrowser(String b) {
		browserType = null;
		
		switch (b) {
		case "C:\\Program Files (x86)\\Internet Explorer\\iexplore.exe":
			browserType = BrowserType.InternetExplorer;
			break;
		case "GoogleChrome":
			browserType = BrowserType.GoogleChrome;
			break;
		case "FireFox":
			browserType = BrowserType.FireFox;
			break;
		case "Headless":
			//browserType = BrowserType.Headless;
			System.out.println("headless started\n");
			break;
		
		
		}
	}

	void initialize(BrowserType browserType, String nodeUrl) throws UnsupportedEncodingException {
		String path = Main.class.getProtectionDomain().getCodeSource().getLocation().getPath(); // get the path of the .jar
		path = URLDecoder.decode(path,"utf-8"); // convert the path format from HTML to UTF
		path = path.substring(1,path.lastIndexOf("/") ); //create a new string by removing the garbage
		System.out.println(path+browserType);
		DesiredCapabilities dc = new DesiredCapabilities();
		switch (browserType) 
		{
		case InternetExplorer:
			//browser = null;
			System.setProperty("webdriver.ie.driver",path+ "\\IEDriverServer.exe");
			
			dc.setBrowserName("internet explorer");
			dc.setPlatform(Platform.WINDOWS);
			System.out.println("Initialize : " + nodeUrl);
			try {
				browser = new RemoteWebDriver(new URL(nodeUrl), dc);
				browser.manage().window().maximize();
				System.out.println("ie Started\n");
			} catch (MalformedURLException e) {

				e.printStackTrace();
			}
			
			waitForLoad(browser);			
			break;
			
		case FireFox:
			System.setProperty("webdriver.firefox.marionette", path+ "\\geckodriver.exe");
			/*ProfilesIni init=new ProfilesIni();
            FirefoxProfile profile=init.getProfile("default");
			*/browser = new FirefoxDriver();
			break;
			
		case GoogleChrome:
			System.setProperty("webdriver.chrome.driver", path+ "\\chromedriver.exe");
			dc.setBrowserName("chrome");
			dc.setPlatform(Platform.WINDOWS);
			ChromeOptions options = new ChromeOptions();
			options.addArguments("--start-maximized");
			dc.setCapability(ChromeOptions.CAPABILITY, options);
			System.out.println("Initialize : " + nodeUrl);
			try {
				browser = new RemoteWebDriver(new URL(nodeUrl), dc);
				browser.manage().timeouts().pageLoadTimeout( 10, TimeUnit.SECONDS );
				System.out.println("Chrome Started\n");
			} catch (MalformedURLException e) {

				e.printStackTrace();
			}
			
			break;
		}
		if (browser == null) {
			throw new NullPointerException("Error: Unable to map to the specified broswer!");
		}
		else {
			if(allCookies != null){
				for(Cookie cookie : allCookies)
				{
					browser.manage().addCookie(cookie);
				}
			}
		}
		browser.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		mainWindowHandle = browser.getWindowHandle();
	}

	void waitForLoad(WebDriver driver) {
		try{
			new WebDriverWait(driver, 30).until((ExpectedCondition<Boolean>) wd ->((JavascriptExecutor) wd).executeScript("return document.readyState").equals("complete"));
		}
		catch (Exception e){
			if(e.getMessage().contains("javascript")){
			e.printStackTrace();
			waitForLoad(driver);
			}
		}
	}

	void highlightControl(WebElement element) {
		for (int i = 0; i < 2; i++) 
		{
			JavascriptExecutor js = (JavascriptExecutor) browser;
			js.executeScript("arguments[0].setAttribute('style', arguments[1]);", element,
					"color: yellow; border: 2px solid yellow;");
			try 
			{
				Thread.sleep(25);
			}
			catch (InterruptedException e) 
			{
				e.printStackTrace();
			}
			js.executeScript("arguments[0].setAttribute('style', arguments[1]);", element, "");
			try
			{
				Thread.sleep(25);
			}
			catch (InterruptedException e) 
			{
				e.printStackTrace();
			}
		}
	}

	void verifyControl(WebElement control, String expression, String attribute, String value) {
		if (control == null) {
			System.out.printf("Contol associated with attribute %s and value %s was not found %nMatch expression: %s",
					attribute, value, expression);
			Close();
		} else
			highlightControl(control);
	}

	Result waitForTimeOut(String[] parameters) throws InterruptedException {

		String actionText = "Wait for set amount of time";
		String expresult = "Execution should be halted for " + parameters[0];
		String result = "Execution is halted for " + parameters[0];
		if (!parameterCheck(parameters, 1))
			return new Result(false, actionText, expresult, "Required values were not passed");

		// Initialize variables for duration and unit
		long duration = 0;
		TimeUnit unit = null;

		// If first parameter passed in is not null, parse it to long value and
		// store in duration variable.
		duration = Long.parseLong(parameters[0]);

		// Get the matching value from TimeUnit and store in unit variable.
		// If no matching value is found, set the unit as seconds.
		//unit = TimeUnit.valueOf(parameters[1]);

		//if (unit == null)
		unit = TimeUnit.SECONDS;

		//browser.manage().timeouts().pageLoadTimeout(duration, unit);
		//WebDriverWait wait = new WebDriverWait(browser, duration * 1000, duration * 1000);
		Thread.sleep(duration * 1000);
		return new Result(true, actionText, expresult, result);
	}

	Result click(WebElement control, ArrayList<String> listobject) {
		// Click on the passed in control
		String actionText = "Perform click on " + listobject.get(0) + "(" + listobject.get(1) + " = \"" + listobject.get(2) + "\")";
		String expresult = listobject.get(0) + " should be clicked";
		String result = listobject.get(0) + " is clicked";
		try{
			control.click();

			/*try{
				JavascriptExecutor js = (JavascriptExecutor)browser;
				js.executeScript("arguments[0].click();", control);
				waitForLoad(browser);
				return new Result(true, controlText + " is clicked");
			}
			catch (Exception f){

			}*/
			return new Result(true, actionText, expresult, result);			

		}
		catch(Exception e){
			//if(e.toString().contains("ElementNotVisible")){
			try{
				JavascriptExecutor js = (JavascriptExecutor)browser;
				js.executeScript("arguments[0].click();", control);
				return new Result(true, actionText, expresult , result);
				/*WebElement parent = control.findElement(By.xpath(".."));
				String parentText = parent.getAttribute("innerText");
				parent.click();
				return new Result(true, controlText + "'s parent " + parentText + " is clicked because given element was not visible");*/
			}

			catch(Exception d){
				System.out.println(e.toString() + d.toString());
				return new Result(false, actionText, expresult , e.toString());
			}
		}	
	}

	Result navigate(String[] parameters, ArrayList<String> listobject) throws InterruptedException {

		String actionText = "Navigate to " + parameters[0];
		String expresult = "Browser URL should be set";
		String result = "Browser URL is set";
		// Check if the parameter array contains the required values
		if (!parameterCheck(parameters, 1))
			return new Result(false, actionText, expresult, "Required values were not passed");

		// Redirect the page to the specified URL
		browser.get(parameters[0]);
		browser.wait();
		System.out.println("Page navigated to " + parameters[0]);
		return new Result(true, actionText, expresult, result);

	}

	Result setText(WebElement control, String[] parameters, ArrayList<String> listobject) {

		String actionText = "Type \"" + parameters[0] + "\" in " + listobject.get(0) + "(" + listobject.get(1) + " = \"" + listobject.get(2) + "\")";;
		String expresult = "Set the text \"" + parameters[0] + "\"";
		String result = "\"" + parameters[0] + "\" is set";
		// Check if the parameter array contains the required values
		if (!parameterCheck(parameters, 1))
			return new Result(false, actionText, expresult, "Required values were not passed");
		control.sendKeys(Keys.CONTROL + "a");
		control.sendKeys(Keys.DELETE);
		// Set the specified text as the passed in control value
		control.sendKeys(parameters[0]);
		System.out.println("Control Text set as " + parameters[0]);
		return new Result(true, actionText, expresult, result);
	}

	Result matchText(WebElement control, String[] parameters, ArrayList<String> listobject) {

		String actionText = "Verify text of " + listobject.get(0) + "(" + listobject.get(1) + " = \"" + listobject.get(2) + "\") matches with " + parameters[0];
		String expresult = "Text should be " + parameters[0];
		String result = "Text is " + parameters[0];
		// Check if the parameter array contains the required values
		if (!parameterCheck(parameters, 1))
			return new Result(false, actionText, expresult, "Required values were not passed");

		if (control == null)
			return new Result(false, actionText, expresult, "Invalid element passed");

		// Change the actual and expected text to lower case to ignore casing

		String expectedValue = parameters[0].trim().toLowerCase();
		String actualValue;
		try {
			actualValue = control.getText().trim().toLowerCase();
		}
		catch (Exception e){
			actualValue = control.getAttribute("innertext").trim().toLowerCase();
		}
		if(actualValue.isEmpty())
			actualValue = control.getAttribute("innerText");
		if (matchGenericText(expectedValue, actualValue)) {
			System.out.println("Control Text matched with " + expectedValue);
			return new Result(true, actionText, expresult, result);
		} else
		{
			System.out.println("Control not matched");
			return new Result(false, actionText, expresult, "Text is not " + parameters[0] + ". Actual text is " + actualValue + ".");	
		}
	}

	Result matchExactText(WebElement control, String[] parameters, ArrayList<String> listobject) {

		String actionText = "Verify text of " + listobject.get(0) + "(" + listobject.get(1) + " = \"" + listobject.get(2) + "\") matches exactly with \"" + parameters[0] + "\"";
		String expresult = "Text should exactly be \"" + parameters[0] + "\"";
		String result = "Text is exactly \"" + parameters[0] + "\"";
		// Check if the parameter array contains the required values
		if (!parameterCheck(parameters, 1))
			return new Result(false,  actionText, expresult, "Required values were not passed");

		if (matchGenericText(control.getAttribute("value"), parameters[0])) {
			System.out.println("Control Text matched with " + parameters[0]);
			return new Result(true, actionText, expresult, result);
		} else
			return new Result(false, actionText, expresult, "Element text not matched");
	}

	Result matchUrl(WebElement control, String[] parameters) {

		String actionText = "Verify browser URL";
		String expresult = "Browser URL should be " + parameters[0];
		String result = "Browser URL is " + parameters[0];
		// Check if the parameter array contains the required values
		if (!parameterCheck(parameters, 1))
			return new Result(false, actionText, expresult, "Required values were not passed");

		// Verify the current browser URL matches the passed in URL
		if (browser.getCurrentUrl().equalsIgnoreCase(parameters[0])) {
			System.out.println("Page URL matched with " + parameters[0]);
			return new Result(true, actionText, expresult, result);
		} else
			return new Result(false, actionText, expresult, "Browser URL is not " + parameters[0] + " (" + browser.getCurrentUrl() + ")");
	}

	Result matchTitle(String[] parameters) {

		String actionText = "Verify page title";
		String expresult = "Page title should be " + parameters[0];
		String result = "Page title is " + parameters[0];
		// Check if the parameter array contains the required values
		if (!parameterCheck(parameters, 1))
			return new Result(false, actionText, expresult, "Required values were not passed");

		// Verify the current page title matches the passed in page title
		if (browser.getTitle().equalsIgnoreCase(parameters[0])) {
			System.out.println("Page Title matched with " + parameters[0]);
			return new Result(true, actionText, expresult, result);
		} else
			return new Result(false, actionText, expresult, "Page title is not " + parameters[0]);
	}

	Result matchDate(WebElement control, String[] parameters, ArrayList<String> listobject) throws ParseException {

		String actionText = "Verify date";
		String expresult = "Date should be " + parameters[0];
		String result = "Date is " + parameters[0];
		// Check if the parameter array contains the required values
		if (!parameterCheck(parameters, 1))
			return new Result(false, actionText, expresult, "Required values were not passed");

		SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
		Date dateValue = dateFormat.parse(parameters[0]);
		Date expectedDate = dateFormat.parse(control.getText());
		if (expectedDate.equals(dateValue)) {
			System.out.println("Date matched with " + parameters[0]);
			return new Result(true, actionText, expresult, result);
		} else
			return new Result(false, actionText, expresult, "Date is not " + parameters[0]);
	}

	Result open(String[] parameters, String nodeUrl) throws UnsupportedEncodingException {

		// Check if the parameter array contains the required values
		/*if (!parameterCheck(parameters, 1))
			return false;*/

		String actionText = "Launch application";
		String expresult = "Application " + parameters[0] + " should launch";
		String result = "Application " + parameters[0] + " is launched";
		try {
			System.out.println(parameters[0]);
			setBrowser(parameters[0]);
			Open(nodeUrl);
			return new Result(true, actionText, expresult, result);
		} catch (NullPointerException e) {
			e.printStackTrace();
			return new Result(false, actionText, expresult, e.toString());
		}
	}

	Result selectByValue(WebElement control, String[] parameters, ArrayList<String> listobject) {

		String actionText = "Select " + parameters[0] + " in " + listobject.get(0) + "(" + listobject.get(1) + " = \"" + listobject.get(2) + "\")";
		String expresult = parameters[0] + " should be selected in " + listobject.get(0);
		String result = parameters[0] + " is selected in " + listobject.get(0);
		// Check if the parameter array contains the required values
		if (!parameterCheck(parameters, 1))
			return new Result(false, actionText, expresult, "Required values were not passed");

		String value = parameters[0].trim();
		List<WebElement> elements = null;
		if (control.getTagName().equalsIgnoreCase("select"))
			elements = control.findElements(By.tagName("option"));
		else
			elements = control.findElements(By.tagName("input"));

		if (elements == null)
			return new Result(false, actionText, expresult, listobject.get(0) + " is null");

		for (WebElement element : elements){
			System.out.println(element.getText());
			if (element.getText().trim().equalsIgnoreCase(value) || element.getAttribute("value").equalsIgnoreCase(value)) {
				if (!element.isSelected())
					element.click();
				return new Result(true, actionText, expresult , result);
			}
		}
		return new Result(false, actionText, expresult, parameters[0] + " of " + listobject.get(0) + " is not selected");
	}

	Result selectByIndex(WebElement control, String[] parameters, ArrayList<String> listobject) {

		String actionText = "Select value at index " + parameters[0] + " in " + listobject.get(0) + "(" + listobject.get(1) + " = \"" + listobject.get(2) + "\")";
		String expresult = "Value at index " + parameters[0] + " should be selected in " + listobject.get(0);
		String result = "Value at index " + parameters[0] + " is selected in " + listobject.get(0);
		// Check if the parameter array contains the required values
		if (!parameterCheck(parameters, 1))
			return new Result(false, actionText, expresult, "Required values were not passed");

		int index = Integer.parseInt(parameters[0].trim());
		List<WebElement> elements = null;
		if (control.getTagName().equalsIgnoreCase("select"))
			elements = control.findElements(By.tagName("option"));
		else
			elements = control.findElements(By.tagName("input"));

		if (elements == null)
			return new Result(true, actionText, expresult , "Could not find value items");

		WebElement element = elements.get(index);

		if (element == null)
			return new Result(true, actionText, expresult , "Value does not exist in the list in the given index (" + parameters[0] + ")");

		if (!element.isSelected())
			element.click();
		return new Result(true, actionText, expresult , result);
	}

	Result objectExists(WebElement control, String[] parameters, ArrayList<String> listobject) {

		String actionText = "Verify that " + listobject.get(0) + "(" + listobject.get(1) + " = \"" + listobject.get(2) + "\") exists";
		String expresult = listobject.get(0) + " should exist";
		// Check if the parameter array contains the required values
		if (!parameterCheck(parameters, 1))
			return new Result(false, actionText, expresult, "Required values were not passed");

		if (parameters[0].equalsIgnoreCase("Yes"))
			return new Result(control != null, actionText, expresult, listobject.get(0) + " exists");
		else if (parameters[0].equalsIgnoreCase("No"))
			return new Result(control == null, actionText, expresult, listobject.get(0) + " does not exist");
		else
			return new Result(false, actionText, expresult, listobject.get(0) + " does not exist");

	}

	boolean matchGenericText(String expectedValue, String actualValue) {

		if (expectedValue.isEmpty() || actualValue.isEmpty())
			return false;

		if(Pattern.matches(expectedValue, actualValue))		
			return true;
		else if(expectedValue.equalsIgnoreCase(actualValue))
			return true;
		else {
			actualValue = actualValue.replace("\n", "").replace("\t", "").replace("\r", "");
			return expectedValue.equalsIgnoreCase(actualValue);
		}
	}

	Result isEmpty(WebElement control, ArrayList<String> listobject) {
		String actionText = "Verify that " + listobject.get(0) + " is empty";
		String expresult = listobject.get(0) + " should be empty";
		String result = listobject.get(0) + " is empty";
		if (control == null)
			return new Result(false, actionText, expresult, listobject.get(0) + " is null");
		return new Result(control.getText().isEmpty(), actionText, expresult, control.getText().isEmpty() ? result : listobject.get(0) + " is not empty");
	}

	Result getListOfItems(WebElement control, String[] parameters, ArrayList<String> listobject) {

		String actionText = "Verify that "  + listobject.get(0) + "(" + listobject.get(1) + " = \"" + listobject.get(2) + "\" has the given items in the test data)";
		String expresult = listobject.get(0) + " should contain all the expected items";
		String result = listobject.get(0) + " contains all the expected items";
		// Check if the parameter array contains the required values
		if (!parameterCheck(parameters, 1))
			return new Result(false, actionText, expresult, "Required values were not passed");

		String[] expectedData = parameters[0].split(";");
		Select select = new Select(control);
		final List<String> actualData = new ArrayList<String>();
		select.getOptions().forEach(element -> actualData.add(element.getText()));
		for (String data : expectedData) {
			if (!actualData.contains(data))
				return new Result(false, actionText, expresult, data + " was not found in the list");
		}
		return new Result(true, actionText, expresult, result);
	}

	public Result sendKeys(String[] parameters, ArrayList<String> listobject) {
		// TODO Auto-generated method stub
		String actionText = "Send keys to the browser";
		String expresult = parameters[0] + " key(s) should be sent to the browser";
		String result = parameters[0] + "key is sent to the browser";
		WebElement ele = browser.switchTo().activeElement();
		try{
			switch(parameters[0]){
			case "{BACKSPACE}":
				ele.sendKeys(Keys.BACK_SPACE);				
			case "{ENTER}":
				ele.sendKeys(Keys.ENTER);				
			case "{ESC}":
				ele.sendKeys(Keys.ESCAPE);
			case "{TAB}":
				ele.sendKeys(Keys.BACK_SPACE);
			case "{HOME}":
				ele.sendKeys(Keys.HOME);
			case "{END}":
				ele.sendKeys(Keys.END);
			case "{PAGEUP}":
				ele.sendKeys(Keys.PAGE_UP);
			case "{PAGEDOWN}":
				ele.sendKeys(Keys.PAGE_DOWN);
			case "{INSERT}":
				ele.sendKeys(Keys.INSERT);
			case "{DELETE}":
				ele.sendKeys(Keys.DELETE);
			case "{UP}":
				ele.sendKeys(Keys.UP);
			case "{DOWN}":
				ele.sendKeys(Keys.DOWN);
			case "{RIGHT}":
				ele.sendKeys(Keys.RIGHT);
			case "{LEFT}":
				ele.sendKeys(Keys.LEFT);
			case "{F1}":
				ele.sendKeys(Keys.F1);
			case "{F2}":
				ele.sendKeys(Keys.F2);
			case "{F3}":
				ele.sendKeys(Keys.F3);
			case "{F4}":
				ele.sendKeys(Keys.F4);
			case "{F5}":
				ele.sendKeys(Keys.F5);
			case "{F6}":
				ele.sendKeys(Keys.F6);
			case "{F7}":
				ele.sendKeys(Keys.F7);
			case "{F8}":
				ele.sendKeys(Keys.F8);
			case "{F9}":
				ele.sendKeys(Keys.F9);
			case "{F10}":
				ele.sendKeys(Keys.F10);
			case "{F11}":
				ele.sendKeys(Keys.F11);
			case "{F12}":
				ele.sendKeys(Keys.F12);				
			default:
				ele = browser.switchTo().activeElement();
				ele.sendKeys(parameters[0]);
				ele.sendKeys(Keys.TAB);
				if(!parameters[0].isEmpty())
				return new Result(true,  actionText, expresult, parameters[0] + " keys are sent");
			}
			return new Result(true, actionText, expresult , result);
		}
		catch(Exception e){
			e.printStackTrace();
			return new Result(false, actionText, expresult, "Key could not be sent");
		}
	}
	
	public void closeAllWindowsBut(){
		Set<String> allWindowHandles = browser.getWindowHandles();
		for (String currentWindowHandle : allWindowHandles) {
			if (!currentWindowHandle.equals(mainWindowHandle)) {
				browser.switchTo().window(currentWindowHandle);
				browser.close();
			}
		}
	}

	static boolean parameterCheck(String[] parameters, int length) {

		// If the parameter array is empty or if no parameters are required,
		// return false.
		/*if (parameters == null || length == 0)
			return false;

		// If the passed in parameter array doesn't match with the expected
		// number of parameters, return false.
		if (parameters.length != length)
			return false;*/

		// If any of the parameters passed in is null, return false. Else,
		// return true.
		for (int i = 0; i < length; i++) {
			if (parameters[i] == null)
				return false;
		}
		return true;
	}
	/*public Result openRemoteBrowser(String[] parameters)
	{
		String actionText = "Open Browser";
		String expresult = parameters[0] + "Browser should Open";
		String actualResult = "Error has occured";
		switch(parameters[0]) {
			case "GoogleChrome":
				DesiredCapabilities dc = new DesiredCapabilities();
				dc.setBrowserName("chrome");
				dc.setPlatform(Platform.WINDOWS);

				try {
					driver = new RemoteWebDriver(new URL("http://192.168.27.68:27871/wd/hub"), dc);
					actualResult = "Browser Opened";
				} catch (MalformedURLException e) {

					e.printStackTrace();
				}
			break;
			case "InternetExplorer":
				break;
			case "FireFox":
				break;
				
				
		}
		return new Result(true, actionText, expresult, actualResult);
	}
	public Result navigateRemoteBrowser(String[] parameters)
	{
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		ChromeOptions options = new ChromeOptions();
		options.addArguments("start-maximized");
		String actionText = "Nvigate to URL";
		String expresult = parameters[0] + " should Open";
		//driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.get(parameters[0]);
		System.out.println(driver.getCurrentUrl());
		return new Result(true, actionText, expresult, "IO error has occurred");
		
	}*/

}