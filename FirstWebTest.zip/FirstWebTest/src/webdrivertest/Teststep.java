package webdrivertest;

public class Teststep {
	String TestCaseName = "";  
	String TestFlowName = "";
	String Steps = "";
	String Action = "";
	String ObjectName = "";
	String ObjectId = "";
	String ExpectedResult = "";
	String ActualResult = "";
	String Screenshot = "";
	String Status = "";
	String ExecutionDate = "";
	String StartTime = "";
	String EndTime = "";
	String Duration = "";
	String Comments = "";
}
