package webdrivertest;

public class Result {
	
	boolean status;
	String result;
	String expresult;
	String action;
	
	public Result(boolean status, String action, String expresult, String result){
		this.status = status;
		this.result = result;
		this.expresult = expresult;
		this.action = action;
	}
}
