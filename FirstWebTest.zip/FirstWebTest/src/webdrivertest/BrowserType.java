package webdrivertest;

public enum BrowserType {
	InternetExplorer, GoogleChrome, FireFox, RemoteIE, RemoteChrome, RemoteFireFox
}
