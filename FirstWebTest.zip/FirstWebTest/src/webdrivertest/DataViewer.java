package webdrivertest;

import org.apache.commons.lang3.*;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.io.IOException;
import java.util.ArrayList;

import javax.swing.JEditorPane;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;

public class DataViewer{

	static ArrayList<ArrayList<String>> list;
	static JFrame frame;
	static JPanel panel;
	static JEditorPane editorPane;
	static JScrollPane editorScrollPane;
	
	/**
	 * @throws IOException 
	 * 
	 */
	//private static final long serialVersionUID = 1L;
	
	
	
	public DataViewer(ArrayList<ArrayList<String>> test) throws IOException{
		DataViewer.list = test;
	}
	
	public static void viewInHTML(Object test){
		list = (ArrayList<ArrayList<String>>) test;
		frame = new JFrame();
		panel = new JPanel(new BorderLayout());
		editorPane = new JEditorPane("text/html", convListToTable());
		editorPane.setVisible(true);
		editorScrollPane = new JScrollPane(editorPane);
		editorScrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
		editorScrollPane.setPreferredSize(new Dimension(960, 640));
		editorScrollPane.setMinimumSize(new Dimension(50, 50));
		editorScrollPane.setVisible(true);
		panel.add(editorScrollPane, BorderLayout.CENTER);
		panel.revalidate();
		panel.setVisible(true);
		frame.add(panel, BorderLayout.CENTER);
		frame.revalidate();
		frame.pack();
		frame.setLocationRelativeTo(null);
        frame.setVisible(true);
	}

	public void close(){
		frame.dispose();
	}
	
	public static String convListToTable(){
		String html = "<!DOCTYPE html><html><head><style>table, td, th {border:1px solid black; border-collapse:collapse;} </style></head><body><table>";
		
		
		for(int i =0;i<list.size();i++){
			html += "<tr>";
			
			for(int j = 0; j < list.get(0).size(); j++){
				html+="<td>";
				html+=StringUtils.replaceEach(list.get(i).get(j), new String[]{"&", "\"", "<", ">"}, new String[]{"&amp;", "&quot;", "&lt;", "&gt;"});
				html+="</td>";
			}
			html += "</tr>";
			
		}
		html+="</table></body></html>";
		
		return html;
		
	}
	
	/*public void changeContent(){
		Document doc = new HTMLDocument();
		doc.
	}*/

}
