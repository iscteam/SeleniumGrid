package webdrivertest;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import com.codoid.products.exception.FilloException;
import com.codoid.products.fillo.Connection;
import com.codoid.products.fillo.Fillo;
import com.codoid.products.fillo.Recordset;

import jxl.Cell;
import jxl.CellView;
import jxl.Workbook;
import jxl.format.Alignment;
import jxl.format.Colour;
import jxl.read.biff.BiffException;
import jxl.write.Formula;
import jxl.write.Label;
import jxl.write.WritableCellFormat;
import jxl.write.WritableFont;
import jxl.write.WritableHyperlink;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;
import jxl.write.WriteException;
import jxl.write.biff.RowsExceededException;

public class ExcelHelper {
	static Map<String, Object> DictionaryObj = new HashMap<String, Object>();
	public static WritableWorkbook newworkbook;
	public static WritableSheet sh = null;
	static String Contents;
	static WritableWorkbook workBook;
	static WritableSheet worksheet;
	static int testStepIndex = 6;

	public static String OpenWorkbook(File fileobj, String handle)
			throws Exception {

		if (fileobj.exists()) {
			try {
				Workbook existingwb = Workbook.getWorkbook(fileobj);
				newworkbook = Workbook.createWorkbook(fileobj, existingwb);
				DictionaryObj.put(handle, newworkbook);
			} catch (BiffException e) {
				newworkbook = Workbook.createWorkbook(fileobj);
				DictionaryObj.put(handle, newworkbook);
			}
			return handle;
		} 
		else {
			newworkbook = Workbook.createWorkbook(fileobj);
			DictionaryObj.put(handle, newworkbook);
			return handle;
		}
	}

	public static void writeWorkbook(String handle) throws IOException,
			WriteException {
		WritableWorkbook workbook = getObject(handle);
		workbook.write();
		//workbook.close();
	}

	public static String openSheet(String handle, String name) throws Exception {
		WritableWorkbook workbook = getObject(handle);
		if (!DictionaryObj.containsKey(handle+name)) {

			if (workbook.getSheet(name) == null) {
				sh = workbook.createSheet(name,
						workbook.getNumberOfSheets() + 1);
				DictionaryObj.put(handle+name, sh);
				return handle+name;
			} else {
				sh = workbook.getSheet(name);
				DictionaryObj.put(handle+name, sh);
				return handle+name;
			}
		}
		return handle+name;
	}

	public static String openSheet(String handle, int index) throws Exception {
		WritableWorkbook workbook = getObject(handle);
		WritableSheet sh = null;
		String name;
		try {
			sh = workbook.getSheet(index);
		} catch (IndexOutOfBoundsException e) {
			System.out.println("Sheet not found in specified index " + index);
		}

		name = sh.getName();

		return name;

	}

	public static void closeSheet(String whandle, String handle) {
		if (!handle.isEmpty()) {
			if (DictionaryObj.containsKey(whandle+handle)) {
				DictionaryObj.remove(whandle+handle);
			} else
				System.out.println("Sheet Handler is already closed!");
		}
	}

	public static <Type> Type getObject(String key) throws IOException {
		if (DictionaryObj.containsKey(key)) {
			if (DictionaryObj.get(key).getClass().toString()
					.contains("WritableWorkbook")) {
				workBook = (WritableWorkbook) DictionaryObj.get(key);
				return (Type) workBook;
			} else if (DictionaryObj.get(key).getClass().toString()
					.contains("WritableSheet")) {
				worksheet = (WritableSheet) DictionaryObj.get(key);
				return (Type) worksheet;
			} else {
				System.out
						.println("Given key contains other than the Workbook/Worksheet ");
				return null;
			}
		} else {
			System.out.println("Workbook/Worksheet not found in the given key");
		}
		return null;
	}

	public static void CloseWorkbook(String handle) throws Exception {
		WritableWorkbook newworkbook;
		if (DictionaryObj.get(handle) != null) {
			if (DictionaryObj.get(handle).getClass().getName()
					.contains("Workbook")) {
				newworkbook = getObject(handle);
				newworkbook.write();
				newworkbook.close();
				System.out.println("Success");
			}
			DictionaryObj.remove(handle);
		} else if (DictionaryObj.get(handle) == null) {
			System.out.println("Key not found in Dictionary");
		} else {
			System.out.println("Unable to add value in Dictionary");
		}
	}

	public static Connection readWorkbook(String filepath)
			throws FilloException {
		Fillo fillo = new Fillo();
		Connection connection = fillo.getConnection(filepath);
		return connection;
	}

	public static Recordset executeQuery(Connection connection, String query)
			throws FilloException {

		Recordset recordset = connection.executeQuery(query);

		return recordset;
	}

	public static ArrayList<ColumnList> find(Recordset recordset,
			String column, String findtext) throws FilloException {

		ArrayList<ColumnList> list = new ArrayList<ColumnList>();
		boolean foundTestCase = false;
		while (recordset.next()) {
			if (!foundTestCase) {
				if (recordset.getField(column).equalsIgnoreCase(findtext)) {
					foundTestCase = true;
					list.add(getRowValue(recordset));
				}
				continue;
			} else if (!(recordset.getField(column).equals("null") || recordset
					.getField(column).trim().isEmpty()))
				break;

			list.add(getRowValue(recordset));

		}

		return list;
	}

	public static ArrayList<String> findRow(Recordset recordset, String column,
			String findtext) throws FilloException {

		while (recordset.next()) {

			if (recordset.getField(column).equalsIgnoreCase(findtext)) {
				return getRowValue(recordset);
			}
		}
		return null;
	}

	private static ColumnList getRowValue(Recordset recordset)
			throws FilloException {
		ColumnList columnlist = new ColumnList();

		for (int j = 0; j < recordset.getFieldNames().size(); j++) {
			columnlist.addValue(recordset.getField(j).value());
		}

		return columnlist;
	}

	public static void closeConnection(Recordset recordset,
			Connection connection) {
		recordset.close();
		connection.close();
	}

	public static void writeFormattedText(String shandler, int col, int row,
			String value, Alignment a, Colour backcolour, WritableFont font)
			throws RowsExceededException, WriteException, IOException 
	{
		WritableSheet writablesheet2 = (WritableSheet) DictionaryObj
				.get(shandler);
		WritableCellFormat wm = new WritableCellFormat(font);
		wm.setAlignment(a);
		if(backcolour != null)
		wm.setBackground(backcolour);

		Label label1 = new Label(col, row, value, wm);
		writablesheet2.addCell(label1);
	}
	
	public static void writeFormattedText(String shandler, int col, int row, String value, WritableCellFormat wm) throws RowsExceededException, WriteException,IOException
    {
         WritableSheet writablesheet2 = getObject(shandler);
         Label label1 = new Label(col, row, value, wm);
         writablesheet2.addCell(label1);
    }

	public static int getLastRow(String whandle, String shandle) throws IOException{
		
		WritableSheet sheet = getObject(whandle+shandle);	
		return sheet.getRows();
		
	}
	
	public static void autoFit(String handle) throws IOException{
		WritableSheet sheet = (WritableSheet) getObject(handle);
		CellView cell;
		for(int x=0;x<sheet.getColumns();x++)
		{
		    cell=sheet.getColumnView(x);
		    cell.setAutosize(true);
		    sheet.setColumnView(x, cell);
		}
	}
	
	public static void logReportFooter(String shandle) throws IOException, RowsExceededException
	 {
	  WritableSheet sheet = getObject(shandle);
	  
	  int columns = sheet.getColumns();
	  int rows = sheet.getRows();
	  CellView cv = new CellView();
	  for(int i =0;i<columns;i++)
	  {
	   int max = 0;
	   for(int j=6;j<rows;j++)
	   {
	    int len = sheet.getCell(i, j).getContents().length();
	    if(max<len)
	    {
	     max = len;
	    }
	   }
	   if(max==0)
	   {
	    int cellLength = ((sheet.getCell(i, 5).getContents().length())+3);
	    sheet.setColumnView(i, cellLength);
	   }
	   else
	   {
	    max = max+2;
	    sheet.setColumnView(i, max);
	   }
	  }
	 }

	/*public static WritableFont getCellFormat(Teststep step) {
		WritableFont font = new WritableFont(WritableFont.TIMES, 11);
		Colour colour;
		switch (step.Status) {
		case "Blocked":
			colour = Colour.ORANGE;
			break;
		case "Failed":
			colour = Colour.RED;
			break;
		case "InProgress":
			colour = Colour.BLUE;
			break;
		case "Passed":
			colour = Colour.GREEN;
			break;
		default:
			colour = Colour.BLACK;
			break;
		}
		try {
			font.setColour(colour);
		} catch (WriteException e) {

			e.printStackTrace();
		}
		return new WritableFont(font);
	}*/

	public static void screenshot(String shandler, int col, int testStepIndex,
			String filepath) throws RowsExceededException, WriteException {
		WritableSheet writablesheet2 = (WritableSheet) DictionaryObj
				.get(shandler);
		
		WritableHyperlink hlk = new WritableHyperlink(col, testStepIndex,
				new File(filepath), "screenshot");
		writablesheet2.addHyperlink(hlk);

	}
	
	public static void sheetAutoFitColumns(String shandler,int c) {
		WritableSheet sheet = (WritableSheet) DictionaryObj.get(shandler);		
		for(int x=0;x<c;x++){
		CellView cell=sheet.getColumnView(x);
		cell.setAutosize(true);
		sheet.setColumnView(x, cell);
		}
	}
		
		
//		for (int i = 0; i < sheet.getColumns(); i++) {
//			Cell[] cells = sheet.getColumn(i);
//			int longestStrLen = -1;
//
//			if (cells.length == 0)
//				continue;
//
//			/* Find the widest cell in the column. */
//			for (int j = 0; j < cells.length; j++) {
//				if (cells[j].getContents().length() > longestStrLen) {
//					String str = cells[j].getContents();
//					if (str == null || str.isEmpty())
//						continue;
//					longestStrLen = str.trim().length();
//				}
//			}
//
//			/* If not found, skip the column. */
//			if (longestStrLen == -1)
//				continue;
//
//			System.out.println(longestStrLen);
//			/* If wider than the max width, crop width */
//			if (longestStrLen > 255)
//				longestStrLen = 255;
//
//			CellView cv = sheet.getColumnView(i);
//			cv.setSize(longestStrLen * 256 + 100); /*
//													 * Every character is 256
//													 * units wide, so scale it.
//													 */
//			sheet.setColumnView(i, cv);
//		}*/
	
	

	/*public static void logProcessStepsDet(Teststep step) throws Exception {
		File fileobj = new File(
				"C:/Users/yjaya/Desktop/Reports/reportdetail.xls");
		String wh = OpenWorkbook(fileobj, "wh");
		String sh = openSheet(wh, "Sheet1");

		WritableFont font = getCellFormat(step);
		writeFormattedText(sh, 0, testStepIndex, step.TestCaseName,
				Alignment.LEFT, Colour.WHITE, font);

		writeFormattedText(sh, 1, testStepIndex, step.TestFlowName,
				Alignment.LEFT, Colour.WHITE, font);
		writeFormattedText(sh, 2, testStepIndex, step.Steps, Alignment.LEFT,
				Colour.WHITE, font);
		writeFormattedText(sh, 3, testStepIndex, step.Action, Alignment.LEFT,
				Colour.WHITE, font);
		writeFormattedText(sh, 4, testStepIndex, step.ExpectedResult,
				Alignment.LEFT, Colour.WHITE, font);
		writeFormattedText(sh, 5, testStepIndex, step.ActualResult,
				Alignment.LEFT, Colour.WHITE, font);

		// writeFormattedText(sh, 6, testStepIndex, step.Screenshot,
		// Alignment.LEFT, Colour.WHITE, font);
		if (!step.Screenshot.isEmpty()) {
			screenshot(sh, 6, testStepIndex, step.Screenshot);
		}

		writeFormattedText(sh, 7, testStepIndex, step.Status, Alignment.LEFT,
				Colour.WHITE, font);
		writeFormattedText(sh, 8, testStepIndex, step.ExecutionDate,
				Alignment.LEFT, Colour.WHITE, font);
		writeFormattedText(sh, 9, testStepIndex, step.StartTime,
				Alignment.LEFT, Colour.WHITE, font);
		writeFormattedText(sh, 10, testStepIndex, step.EndTime, Alignment.LEFT,
				Colour.WHITE, font);
		writeFormattedText(sh, 11, testStepIndex, step.Duration,
				Alignment.LEFT, Colour.WHITE, font);
		testStepIndex++;
		sheetAutoFitColumns(sh,12);
		closeSheet(sh);
		// closeWorkbook(wh);
		CloseWorkbook(wh);
	}

	public static void logProcessStepsSum(Teststep step) throws Exception {
		File fileobj = new File(
				"C:/Users/yjaya/Desktop/Reports/reportsummary.xls");
		String wh = OpenWorkbook(fileobj, "wh");
		String sh = openSheet(wh, "Sheet1");
		WritableFont font = getCellFormat(step);
		writeFormattedText(sh, 0, testStepIndex, step.TestCaseName,
				Alignment.LEFT, Colour.WHITE, font);

		writeFormattedText(sh, 1, testStepIndex, step.Status, Alignment.LEFT,
				Colour.WHITE, font);
		// writeFormattedText(sh, 6, testStepIndex, step.Screenshot,
		// Alignment.LEFT, Colour.WHITE, font);
		if (!step.Screenshot.isEmpty()) {
			screenshot(sh, 2, testStepIndex, step.Screenshot);
		}

		writeFormattedText(sh, 3, testStepIndex, step.ExecutionDate,
				Alignment.LEFT, Colour.WHITE, font);
		writeFormattedText(sh, 4, testStepIndex, step.StartTime,
				Alignment.LEFT, Colour.WHITE, font);
		writeFormattedText(sh, 5, testStepIndex, step.EndTime, Alignment.LEFT,
				Colour.WHITE, font);
		writeFormattedText(sh, 6, testStepIndex, step.Duration, Alignment.LEFT,
				Colour.WHITE, font);
		writeFormattedText(sh, 7, testStepIndex, step.Comments, Alignment.LEFT,
				Colour.WHITE, font);
		testStepIndex++;
		sheetAutoFitColumns(sh,8);
		closeSheet(sh);
		// closeWorkbook(wh);
		CloseWorkbook(wh);
	}

	private static void sheetAutoFitColumns(String shandler,int c) {
		WritableSheet sheet = (WritableSheet) DictionaryObj.get(shandler);
		
		for(int x=0;x<c;x++){
		CellView cell=sheet.getColumnView(x);
		cell.setAutosize(true);
		sheet.setColumnView(x, cell);
		}
		
		
//		for (int i = 0; i < sheet.getColumns(); i++) {
//			Cell[] cells = sheet.getColumn(i);
//			int longestStrLen = -1;
//
//			if (cells.length == 0)
//				continue;
//
//			/* Find the widest cell in the column. */
//			for (int j = 0; j < cells.length; j++) {
//				if (cells[j].getContents().length() > longestStrLen) {
//					String str = cells[j].getContents();
//					if (str == null || str.isEmpty())
//						continue;
//					longestStrLen = str.trim().length();
//				}
//			}
//
//			/* If not found, skip the column. */
//			if (longestStrLen == -1)
//				continue;
//
//			System.out.println(longestStrLen);
//			/* If wider than the max width, crop width */
//			if (longestStrLen > 255)
//				longestStrLen = 255;
//
//			CellView cv = sheet.getColumnView(i);
//			cv.setSize(longestStrLen * 256 + 100); /*
//													 * Every character is 256
//													 * units wide, so scale it.
//													 */
//			sheet.setColumnView(i, cv);
//		}*/
	

}