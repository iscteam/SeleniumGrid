package webdrivertest;

public enum ControlType {
	Generic, Text, Password, Button, WildCard

}
