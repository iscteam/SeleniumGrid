package webdrivertest;

import java.io.File;
import java.io.IOException;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.testng.TestListenerAdapter;
import org.testng.TestNG;
import org.testng.xml.XmlClass;
import org.testng.xml.XmlSuite;
import org.testng.xml.XmlTest;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;


public class Main 
{
	public static void main(String[] args)
	{
		DocumentBuilder dBuilder;
		String xmlFilePath = "E:\\Automation\\New folder\\Selenium\\SeleniumFramework\\Config.xml";
		File xmlFile = new File(xmlFilePath);
		DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
		int nodeCount = 0;
		List<String> nodeURLs = new ArrayList<String>();
		//Read from XML file
		try {
			dBuilder = dbFactory.newDocumentBuilder();
			Document doc = dBuilder.parse(xmlFile);
			doc.getDocumentElement().normalize();
			NodeList nodeList = doc.getElementsByTagName("Node");
			
			nodeCount = nodeList.getLength();
			for (int i = 0; i < nodeCount; i++) {
				nodeURLs.add(nodeList.item(i).getTextContent());
				//System.out.println(nodeList.item(i).getTextContent());
            }
			
		} catch (SAXException | ParserConfigurationException | IOException e) {
			e.printStackTrace();
		}
		
		System.out.println("Inside Main: " + nodeCount);
		
		TestNG testNG = new TestNG();
		
		XmlSuite mySuite = new XmlSuite();
		mySuite.setName("MySuite");
		mySuite.setParallel(XmlSuite.ParallelMode.TESTS);
		mySuite.setVerbose(1);
		
		List<XmlTest> myTests = new ArrayList<XmlTest>();
		
		List<XmlSuite> mySuites = new ArrayList<XmlSuite>();
		XmlTest myTest = new XmlTest();
		
	
		for (int i = 0; i<nodeCount; i++)
		{
			
			
			myTest = new XmlTest(mySuite);
			myTest.setName("Node"+i);
			myTest.addParameter("NodeURL", nodeURLs.get(i));
			
			List<XmlClass> myClass = new ArrayList<XmlClass> ();
			myClass.add(new XmlClass(MainTest.class));
			
			myTest.setXmlClasses(myClass);
		    myTests.add(myTest);
		    
		   System.out.println("Node" + i);
		   System.out.println("parameters" + nodeURLs.get(i));
			
		}
		
		mySuite.setTests(myTests);
		mySuites.add(mySuite);
		testNG.setXmlSuites(mySuites);
		testNG.run();
		
	}
}

