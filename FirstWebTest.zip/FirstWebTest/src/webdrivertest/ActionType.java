package webdrivertest;

public enum ActionType {
	Open, Navigate, Click, RightClick, OnMouseOver, SetText, MatchTitle, MatchPartialText, MatchText, MatchDate, MatchURL, MatchExactText, Wait, SelectByValue, SelectByIndex, ObjectExists, IsEmpty, IsEnabled, GetListOfItems, Close, SetTextbySendKeys, SaveWebPage, SendKeys, SetCheck, WebTable, OpenBrowser, NavigateBrowser
}
